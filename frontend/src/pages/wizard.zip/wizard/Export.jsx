import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Download, Loader2, AlertTriangle, Check, ArrowLeft, ArrowRight,
  FileText, Printer, Globe, Settings2, Eye, Sparkles, CheckCircle2,
  FileCheck2, FileType2, FileCode2, FileJson, Wand2, Copy, ExternalLink,
  X, Code2,
} from 'lucide-react'
import WizardShell from '../../components/WizardShell.jsx'
import { useWizard } from '../../context/WizardContext.jsx'
import { MATIERE_LABEL, NIVEAU_LABEL } from '../../data/mockData.js'

const WIZARD_STEPS = [
  { n: 1, label: 'Sélection' },
  { n: 2, label: 'Édition' },
  { n: 3, label: 'Validation' },
  { n: 4, label: 'Export' },
]
const CURRENT_STEP = 4

const FOCUS_RING = 'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0f172a]/35 focus-visible:ring-offset-2'
const HOVER_LIFT = 'motion-reduce:transition-none motion-reduce:hover:translate-y-0'

/* ===== FORMATS D'EXPORT ===== */
const FORMATS = [
  {
    id: 'pdf',
    label: 'PDF',
    description: 'Idéal pour imprimer et partager',
    icon: FileText,
    extension: '.pdf',
    tag: 'Recommandé',
    tagTone: 'emerald',
    enabled: true,
    nature: 'binaire',
  },
  {
    id: 'impression',
    label: 'Impression directe',
    description: 'Ouvre la boîte de dialogue d\'impression',
    icon: Printer,
    extension: null,
    tag: null,
    tagTone: null,
    enabled: true,
    nature: 'impression',
  },
  {
    id: 'docx',
    label: 'Word (.docx)',
    description: 'Modifiable dans Word ou LibreOffice',
    icon: FileType2,
    extension: '.docx',
    tag: null,
    tagTone: null,
    enabled: true,
    nature: 'binaire',
  },
  {
    id: 'md',
    label: 'Markdown (.md)',
    description: 'Format texte — peut s\'ouvrir dans Word par défaut',
    icon: FileCode2,
    extension: '.md',
    tag: null,
    tagTone: null,
    enabled: true,
    nature: 'texte',        // ⬅️ déclenche le modal "Ouvrir avec…"
  },
  {
    id: 'json',
    label: 'JSON',
    description: 'Données structurées — à ouvrir avec un éditeur',
    icon: FileJson,
    extension: '.json',
    tag: null,
    tagTone: null,
    enabled: true,
    nature: 'texte',        // ⬅️ déclenche le modal "Ouvrir avec…"
  },
]

/* ===== OUTILS EN LIGNE PAR FORMAT ===== */
const OUTILS_EN_LIGNE = {
  md: [
    { label: 'VS Code Web', url: 'https://vscode.dev/', icon: Code2 },
    { label: 'StackEdit', url: 'https://stackedit.io/app#', icon: ExternalLink },
    { label: 'Dillinger', url: 'https://dillinger.io/', icon: ExternalLink },
  ],
  json: [
    { label: 'JSON Viewer', url: 'https://jsonviewer.stack.hu/', icon: Code2 },
    { label: 'JSON Editor Online', url: 'https://jsoneditoronline.org/', icon: ExternalLink },
    { label: 'VS Code Web', url: 'https://vscode.dev/', icon: Code2 },
  ],
}

const ETAPES_GENERATION = [
  { label: 'Préparation du document…', icon: FileText },
  { label: 'Application du barème…', icon: FileCheck2 },
  { label: 'Mise en page…', icon: Settings2 },
  { label: 'Finalisation de l\'export…', icon: Wand2 },
]

const TAG_TONES = {
  emerald: 'bg-emerald-100 text-emerald-700',
  amber: 'bg-amber-100 text-amber-700',
  navy: 'bg-[#0f172a]/[0.08] text-[#0f172a]/60',
}

export default function Export() {
  const navigate = useNavigate()
  const { examen, exporterExamen, loading, error } = useWizard()

  const [langue, setLangue] = useState('fr')
  const [format, setFormat] = useState('pdf')
  const [enTete, setEnTete] = useState(true)
  const [pagination, setPagination] = useState(true)
  const [fichierUrl, setFichierUrl] = useState(null)
  const [fichierNom, setFichierNom] = useState(null)
  const [generation, setGeneration] = useState(false)
  const [lastError, setLastError] = useState(null)
  const [showOuvrirAvec, setShowOuvrirAvec] = useState(false)
  const [contenuTexte, setContenuTexte] = useState(null)
  const [copie, setCopie] = useState(false)

  // ===== AJOUT : export du corrigé — ne touche à aucune ligne ci-dessus =====
  const { exporterCorrection } = useWizard()
  const [genererCorrige, setGenererCorrige] = useState(false)
  const [erreurCorrige, setErreurCorrige] = useState(null)
  // ===== FIN AJOUT (état) =====

  const premiereQuestion = examen.questions?.[0]
  const formatSelectionne = FORMATS.find((f) => f.id === format) || FORMATS[0]
  const pret = Boolean(fichierUrl)

  /* ===== GÉNÉRATION ===== */
  async function handleGenerer() {
    setGeneration(true)
    setLastError(null)

    try {
      // 1. Impression → on génère un PDF et on l'ouvre dans un onglet
      const formatBackend = format === 'impression' ? 'pdf' : format

      // 2. Appel backend
      const blob = await exporterExamen({
        format: formatBackend,
        langue,
        en_tete: enTete,
        pagination,
        nom_etablissement: '',
      })

      const url = URL.createObjectURL(blob)
      const ext = formatSelectionne.extension || '.pdf'
      const nom = `examen_${examen.id}${ext}`

      // 3. Impression → nouvel onglet + window.print()
      if (format === 'impression') {
        const win = window.open(url, '_blank', 'noopener,noreferrer')
        if (win) {
          win.addEventListener('load', () => {
            try { win.print() } catch { /* ignoré */ }
          })
        }
        return
      }

      // 4. Formats texte (md / json) → on lit le contenu pour le proposer
      if (formatSelectionne.nature === 'texte') {
        const texte = await blob.text()
        setContenuTexte(texte)
        setFichierUrl(url)
        setFichierNom(nom)
        setShowOuvrirAvec(true)   // ⬅️ ouvre le modal
        return
      }

      // 5. Formats binaires (pdf / docx) → téléchargement direct
      setFichierUrl(url)
      setFichierNom(nom)
      declencherTelechargement(url, nom)
    } catch (err) {
      setLastError(err?.message || 'Erreur lors de la génération du fichier.')
    } finally {
      setGeneration(false)
    }
  }

  function declencherTelechargement(url, filename) {
    const a = document.createElement('a')
    a.href = url
    a.download = filename
    document.body.appendChild(a)
    a.click()
    a.remove()
  }

  function handleReinitialiser() {
    if (fichierUrl) URL.revokeObjectURL(fichierUrl)
    setFichierUrl(null)
    setFichierNom(null)
    setLastError(null)
    setContenuTexte(null)
    setShowOuvrirAvec(false)
  }

  async function handleCopier() {
    if (!contenuTexte) return
    try {
      await navigator.clipboard.writeText(contenuTexte)
      setCopie(true)
      setTimeout(() => setCopie(false), 2000)
    } catch {
      setLastError('Impossible de copier dans le presse-papiers.')
    }
  }

  function handleOuvrirOnglet(url) {
    window.open(url, '_blank', 'noopener,noreferrer')
  }

  // ===== AJOUT : téléchargement du corrigé — fonction entièrement nouvelle,
  // n'appelle que des éléments déjà existants (declencherTelechargement,
  // exporterCorrection) sans modifier handleGenerer ni rien d'autre =====
  async function handleTelechargerCorrige() {
    setGenererCorrige(true)
    setErreurCorrige(null)
    try {
      const blob = await exporterCorrection({
        format: 'pdf',
        langue,
        en_tete: enTete,
        pagination,
        nom_etablissement: '',
      })
      const url = URL.createObjectURL(blob)
      const nom = `corrige_examen_${examen.id}.pdf`
      declencherTelechargement(url, nom)
    } catch (err) {
      setErreurCorrige(err?.message || 'Erreur lors de la génération du corrigé.')
    } finally {
      setGenererCorrige(false)
    }
  }
  // ===== FIN AJOUT (fonction) =====

  /* ===== GARDE : AUCUN EXAMEN ===== */
  if (!examen.id) {
    return (
      <WizardShell step={4} hideStepper>
        <div className="mx-auto max-w-lg py-14 text-center">
          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-[#7a0008]/[0.08] text-[#7a0008]">
            <FileText size={22} />
          </div>
          <h1 className="examai-serif text-[20px] font-semibold text-[#0f172a]">Aucun examen en cours</h1>
          <p className="mt-2 text-[13.5px] font-bold italic text-[#0f172a]/55">
            Retournez à l'étape 1 pour générer un examen avant de pouvoir l'exporter.
          </p>
          <button
            onClick={() => navigate('/wizard/selection')}
            className={`mt-5 inline-flex items-center gap-2 rounded-full bg-[#7a0008] px-6 py-3 text-[13.5px] font-semibold text-white shadow-[0_1px_2px_rgba(15,23,42,0.2),0_10px_22px_-8px_rgba(122,0,8,0.5)] transition-all hover:-translate-y-0.5 active:scale-[0.985] ${FOCUS_RING}`}
          >
            Aller à la sélection <ArrowRight size={15} />
          </button>
        </div>
      </WizardShell>
    )
  }

  const matiereLabel = MATIERE_LABEL[examen.matiere] || examen.matiere
  const niveauLabel = NIVEAU_LABEL[examen.niveau] || examen.niveau
  const nbQuestions = examen.questions?.length || 0
  const totalPoints = examen.questions?.reduce((s, q) => s + (Number(q.points) || 0), 0) || 0

  return (
    <WizardShell step={4} hideStepper>
      <style>{`
        .examai-underline-wave {
          background-color: rgba(122,0,8,0.12);
          background-repeat: no-repeat;
          background-size: 100% 0.35em;
          background-position: 0 88%;
          padding: 0 0.15em;
        }
        @keyframes examaiPulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }
        .examai-pulse { animation: examaiPulse 1.6s ease-in-out infinite; }

        @keyframes examaiSpinSlow { to { transform: rotate(360deg); } }
        @keyframes examaiOrbitPulse {
          0%, 100% { transform: scale(1); opacity: 0.6; }
          50% { transform: scale(1.08); opacity: 1; }
        }
        @keyframes examaiScanLine {
          0% { transform: translateY(-100%); }
          100% { transform: translateY(400%); }
        }
        @keyframes examaiFadeInUp {
          from { opacity: 0; transform: translateY(8px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes examaiDot {
          0%, 20% { opacity: 0.3; transform: scale(0.8); }
          50% { opacity: 1; transform: scale(1.1); }
          80%, 100% { opacity: 0.3; transform: scale(0.8); }
        }
        @keyframes examaiModalFadeIn { from { opacity: 0 } to { opacity: 1 } }
        @keyframes examaiModalSlideUp {
          from { opacity: 0; transform: translateY(16px) scale(0.97); }
          to   { opacity: 1; transform: translateY(0) scale(1); }
        }

        .examai-orbit { animation: examaiSpinSlow 2.4s linear infinite; }
        .examai-orbit-slow { animation: examaiSpinSlow 3.6s linear infinite reverse; }
        .examai-orbit-pulse { animation: examaiOrbitPulse 2s ease-in-out infinite; }
        .examai-scan { animation: examaiScanLine 2s ease-in-out infinite; }
        .examai-fade-in-up { animation: examaiFadeInUp 0.5s cubic-bezier(0.22, 1, 0.36, 1) both; }
        .examai-dot-1 { animation: examaiDot 1.4s ease-in-out infinite; }
        .examai-dot-2 { animation: examaiDot 1.4s ease-in-out 0.2s infinite; }
        .examai-dot-3 { animation: examaiDot 1.4s ease-in-out 0.4s infinite; }

        @media (prefers-reduced-motion: reduce) {
          .examai-pulse, .examai-orbit, .examai-orbit-slow, .examai-orbit-pulse,
          .examai-scan, .examai-fade-in-up, .examai-dot-1, .examai-dot-2, .examai-dot-3 {
            animation: none !important;
          }
        }
      `}</style>

      <div className="w-full max-w-full overflow-x-hidden">

        {/* ===== EN-TÊTE ===== */}
        <div className="relative mb-6 w-full overflow-hidden rounded-[28px] border border-[#0f172a]/20 bg-white p-6 sm:p-8">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div className="min-w-0 flex-1">
              <h1 className="examai-serif text-[30px] sm:text-[40px] lg:text-[42px] font-semibold tracking-[-0.025em] text-[#0f172a] leading-[1.15]">
                Finaliser{' '}
                <span className="text-[#7a0008] relative">
                  <span className="examai-underline-wave">et exporter.</span>
                </span>
              </h1>
              <p className="examai-serif mt-3 text-[14px] sm:text-[15px] font-normal italic leading-[1.6] text-[#0f172a]/75">
                Choisissez le format de votre choix et générez votre fichier.
              </p>
            </div>

            <div
              className={`flex shrink-0 items-center gap-2 rounded-full border-2 px-3 py-1.5 text-[11.5px] font-semibold transition-all ${
                pret ? 'border-emerald-500 bg-emerald-50/40' : 'border-[#0f172a]/15 bg-white'
              }`}
            >
              {pret ? (
                <>
                  <Check size={12} className="text-emerald-600" strokeWidth={3} />
                  <span className="font-bold text-emerald-700">Fichier prêt</span>
                </>
              ) : (
                <>
                  <Sparkles size={12} className="text-[#0f172a]/50" />
                  <span className="text-[#0f172a]/60">Prêt à exporter</span>
                </>
              )}
            </div>
          </div>
        </div>

        {/* ===== ERREURS ===== */}
        {(error || lastError) && (
          <div role="alert" className="mb-5 flex items-start gap-3 rounded-[16px] border border-[#7a0008]/40 bg-[#0f172a]/[0.035] p-4 text-[13px] text-[#0f172a]">
            <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[#7a0008]/10">
              <AlertTriangle size={14} className="text-[#7a0008]" />
            </span>
            <span className="min-w-0 break-words pt-0.5 font-medium">{lastError || error}</span>
          </div>
        )}

        {/* ===== STEPPER ===== */}
        <div className="mb-5 flex items-center rounded-[20px] border border-[#0f172a]/20 bg-white px-5 py-4" role="list" aria-label="Étapes de création de l'examen">
          {WIZARD_STEPS.map((s, i) => {
            const active = s.n === CURRENT_STEP
            const done = s.n < CURRENT_STEP
            return (
              <div key={s.n} role="listitem" className="flex flex-1 items-center last:flex-none">
                <div className="flex items-center gap-2.5">
                  <span className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-[13px] font-bold transition-colors ${
                    active
                      ? 'bg-[#7a0008] text-white shadow-[0_6px_14px_-4px_rgba(122,0,8,0.5)]'
                      : done
                        ? 'bg-[#7a0008]/10 text-[#7a0008]'
                        : 'bg-[#0f172a]/[0.06] text-[#0f172a]/40'
                  }`}>
                    {done ? <Check size={14} strokeWidth={3} /> : s.n}
                  </span>
                  <span className={`whitespace-nowrap text-[13px] font-semibold ${
                    active ? 'text-[#7a0008]' : done ? 'text-[#0f172a]/70' : 'text-[#0f172a]/40'
                  }`}>{s.label}</span>
                </div>
                {i < WIZARD_STEPS.length - 1 && (
                  <span className={`mx-3 h-px flex-1 rounded-full ${done ? 'bg-[#7a0008]/25' : 'bg-[#0f172a]/10'}`} />
                )}
              </div>
            )
          })}
        </div>

        {/* ===== LOADER ===== */}
        {generation && <GenerationLoader formatLabel={formatSelectionne.label} />}

        {/* ===== CONTENU ===== */}
        {!generation && (
          <div className="grid gap-5 lg:grid-cols-[1fr_360px] lg:items-start">

            {/* ===== APERÇU ===== */}
            <div className="min-w-0 rounded-[24px] border border-[#0f172a]/20 bg-white p-6">
              <div className="flex items-center gap-3">
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-[13px] bg-[#0f172a]/[0.08] text-[#0f172a]">
                  <Eye size={17} />
                </span>
                <div className="min-w-0">
                  <p className="examai-serif truncate text-[16.5px] font-semibold text-[#0f172a]">Aperçu du rendu</p>
                  <p className="mt-0.5 truncate text-[11.5px] text-[#0f172a]/50">Voici à quoi ressemblera votre document</p>
                </div>
              </div>

              <div className="mt-5 rounded-[18px] border border-[#7a0008]/10 bg-[#faf6f5] p-6 text-xs text-[#4f0005]/70">
                {enTete && (
                  <div className="mb-4 border-b border-[#7a0008]/15 pb-3 text-center">
                    <p className="examai-serif text-[13px] font-semibold uppercase tracking-wider text-[#7a0008]/70">
                      Établissement scolaire
                    </p>
                    <p className="mt-0.5 text-[10.5px] italic text-[#7a0008]/50">
                      Année scolaire 2024 — 2025
                    </p>
                  </div>
                )}

                <p className="text-center examai-serif text-[15px] font-semibold text-[#250002]">
                  EXAMEN DE {matiereLabel.toUpperCase()}
                </p>
                <p className="mt-1 text-center text-[11px] text-[#4f0005]/50">
                  {niveauLabel} — {examen.chapitre}
                </p>

                <div className="mt-5 space-y-1.5">
                  <div className="flex justify-between gap-2 text-[11px] text-[#4f0005]/55">
                    <span>Nom : ____________</span>
                    <span>Prénom : ____________</span>
                  </div>
                  <div className="flex justify-between gap-2 text-[11px] text-[#4f0005]/55">
                    <span>Classe : ____________</span>
                    <span>Date : ____________</span>
                  </div>
                </div>

                <div className="mt-4 flex justify-end">
                  <div className="flex items-center gap-2 rounded-[8px] border border-[#7a0008]/20 px-3 py-1 text-[10.5px] font-semibold text-[#7a0008]">
                    Note : ____ / 20
                  </div>
                </div>

                {premiereQuestion && (
                  <div className="mt-5 border-t border-[#7a0008]/15 pt-4">
                    <div className="flex items-start justify-between gap-2">
                      <p className="text-[12px] font-semibold text-[#250002]">
                        1. {premiereQuestion.question || <span className="italic text-[#4f0005]/40">Énoncé vide</span>}
                      </p>
                      <span className="shrink-0 rounded-full bg-[#7a0008]/[0.08] px-2 py-0.5 text-[10px] font-bold text-[#7a0008]">
                        {premiereQuestion.points} pt
                      </span>
                    </div>

                    {premiereQuestion.type === 'qcm' && premiereQuestion.options && (
                      <ul className="mt-2 space-y-1">
                        {premiereQuestion.options.slice(0, 4).map((o, i) => (
                          <li key={i} className="flex items-center gap-2 text-[11px] text-[#4f0005]/70">
                            <span className="flex h-4 w-4 items-center justify-center rounded-full border border-[#7a0008]/25 text-[9px] font-bold text-[#7a0008]">
                              {String.fromCharCode(65 + i)}
                            </span>
                            {o || <span className="italic text-[#4f0005]/30">Option vide</span>}
                          </li>
                        ))}
                      </ul>
                    )}

                    {premiereQuestion.type === 'vrai_faux' && (
                      <div className="mt-2 flex gap-3 text-[11px] text-[#4f0005]/70">
                        <span className="flex items-center gap-1.5">
                          <span className="h-3 w-3 rounded-full border border-[#7a0008]/30" /> Vrai
                        </span>
                        <span className="flex items-center gap-1.5">
                          <span className="h-3 w-3 rounded-full border border-[#7a0008]/30" /> Faux
                        </span>
                      </div>
                    )}

                    {(premiereQuestion.type === 'ouverte' || premiereQuestion.type === 'texte_trous') && (
                      <div className="mt-2 space-y-1.5">
                        <div className="h-px w-full bg-[#7a0008]/15" />
                        <div className="h-px w-5/6 bg-[#7a0008]/15" />
                        <div className="h-px w-3/4 bg-[#7a0008]/15" />
                      </div>
                    )}
                  </div>
                )}

                {pagination && (
                  <div className="mt-5 border-t border-[#7a0008]/15 pt-3 text-center text-[10px] italic text-[#4f0005]/40">
                    Page 1 / 3
                  </div>
                )}
              </div>

              <div className="mt-4 flex flex-wrap items-center gap-2 text-[11px] text-[#0f172a]/50">
                <span className="flex items-center gap-1.5 rounded-full bg-[#0f172a]/[0.05] px-2.5 py-1">
                  <FileText size={11} />
                  {nbQuestions} question{nbQuestions > 1 ? 's' : ''}
                </span>
                <span className="flex items-center gap-1.5 rounded-full bg-[#0f172a]/[0.05] px-2.5 py-1">
                  <CheckCircle2 size={11} />
                  {totalPoints} point{totalPoints > 1 ? 's' : ''}
                </span>
                <span className="flex items-center gap-1.5 rounded-full bg-[#7a0008]/[0.06] px-2.5 py-1 font-semibold text-[#7a0008]">
                  <formatSelectionne.icon size={11} />
                  {formatSelectionne.label}
                </span>
              </div>

              {pret && fichierNom && (
                <div className="mt-4 flex items-center justify-between gap-3 rounded-[14px] border border-emerald-500/30 bg-emerald-50/40 p-3.5">
                  <div className="flex min-w-0 items-center gap-2.5">
                    <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-emerald-100">
                      <CheckCircle2 size={15} className="text-emerald-600" strokeWidth={2.4} />
                    </span>
                    <div className="min-w-0">
                      <p className="text-[12.5px] font-bold text-emerald-800">Fichier généré</p>
                      <p className="truncate text-[11px] italic text-emerald-700/70">{fichierNom}</p>
                    </div>
                  </div>
                  <button
                    onClick={handleReinitialiser}
                    className={`shrink-0 rounded-full border border-emerald-500/40 bg-white px-3 py-1.5 text-[11px] font-semibold text-emerald-700 transition-colors hover:bg-emerald-50 ${FOCUS_RING}`}
                  >
                    Régénérer
                  </button>
                </div>
              )}
            </div>

            {/* ===== OPTIONS ===== */}
            <div className="space-y-4">

              {/* Langue */}
              <div className="rounded-[24px] border border-[#0f172a]/20 bg-white p-5">
                <div className="flex items-center gap-2.5">
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-[11px] bg-[#0f172a]/[0.08] text-[#0f172a]">
                    <Globe size={15} />
                  </span>
                  <div className="min-w-0">
                    <p className="examai-serif text-[15px] font-semibold text-[#0f172a]">Langue du rendu</p>
                    <p className="text-[10.5px] font-bold italic text-[#0f172a]/45">Langue du document</p>
                  </div>
                </div>

                <div className="mt-3 space-y-1.5">
                  {[
                    { id: 'fr', label: 'Français' },
                    { id: 'ar', label: 'العربية', disabled: true, tag: 'Bientôt' },
                    { id: 'bilingue', label: 'Bilingue FR + AR', disabled: true, tag: 'Bientôt' },
                  ].map((opt) => (
                    <label
                      key={opt.id}
                      className={`flex items-center justify-between gap-2 rounded-[12px] border px-3 py-2 text-[13px] transition-colors ${
                        opt.disabled
                          ? 'cursor-not-allowed border-[#0f172a]/10 bg-[#0f172a]/[0.02] text-[#0f172a]/35'
                          : langue === opt.id
                            ? 'cursor-pointer border-[#7a0008]/40 bg-[#7a0008]/[0.04] text-[#0f172a]'
                            : 'cursor-pointer border-[#0f172a]/15 text-[#0f172a]/70 hover:border-[#0f172a]/30'
                      }`}
                    >
                      <span className="flex items-center gap-2.5">
                        <input
                          type="radio"
                          name="langue"
                          checked={langue === opt.id}
                          disabled={opt.disabled}
                          onChange={() => setLangue(opt.id)}
                          className="h-4 w-4 border-[#0f172a]/30 text-[#7a0008] focus:ring-[#7a0008]/30 disabled:cursor-not-allowed"
                        />
                        <span className="font-medium">{opt.label}</span>
                      </span>
                      {opt.tag && (
                        <span className={`rounded-full px-2 py-0.5 text-[9.5px] font-bold uppercase tracking-wider ${TAG_TONES.amber}`}>
                          {opt.tag}
                        </span>
                      )}
                    </label>
                  ))}
                </div>
              </div>

              {/* Format */}
              <div className="rounded-[24px] border border-[#0f172a]/20 bg-white p-5">
                <div className="flex items-center gap-2.5">
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-[11px] bg-[#0f172a]/[0.08] text-[#0f172a]">
                    <FileText size={15} />
                  </span>
                  <div className="min-w-0">
                    <p className="examai-serif text-[15px] font-semibold text-[#0f172a]">Format de sortie</p>
                    <p className="text-[10.5px] font-bold italic text-[#0f172a]/45">Type de fichier</p>
                  </div>
                </div>

                <div className="mt-3 space-y-1.5">
                  {FORMATS.map((opt) => {
                    const Icon = opt.icon
                    const active = format === opt.id
                    return (
                      <label
                        key={opt.id}
                        className={`flex cursor-pointer items-start justify-between gap-2 rounded-[12px] border px-3 py-2.5 transition-colors ${
                          active
                            ? 'border-[#7a0008]/40 bg-[#7a0008]/[0.04]'
                            : 'border-[#0f172a]/15 hover:border-[#0f172a]/30'
                        }`}
                      >
                        <span className="flex min-w-0 items-start gap-2.5">
                          <input
                            type="radio"
                            name="format"
                            checked={active}
                            onChange={() => setFormat(opt.id)}
                            className="mt-0.5 h-4 w-4 shrink-0 border-[#0f172a]/30 text-[#7a0008] focus:ring-[#7a0008]/30"
                          />
                          <Icon size={14} className="mt-0.5 shrink-0 text-[#0f172a]/60" />
                          <span className="min-w-0">
                            <span className="block text-[13px] font-medium text-[#0f172a]">
                              {opt.label}
                            </span>
                            <span className="mt-0.5 block text-[10.5px] italic text-[#0f172a]/50">
                              {opt.description}
                            </span>
                          </span>
                        </span>
                        {opt.tag && (
                          <span className={`shrink-0 rounded-full px-2 py-0.5 text-[9.5px] font-bold uppercase tracking-wider ${TAG_TONES[opt.tagTone] || TAG_TONES.navy}`}>
                            {opt.tag}
                          </span>
                        )}
                      </label>
                    )
                  })}
                </div>
              </div>

              {/* Options avancées */}
              <div className="rounded-[24px] border border-[#0f172a]/20 bg-white p-5">
                <div className="flex items-center gap-2.5">
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-[11px] bg-[#0f172a]/[0.08] text-[#0f172a]">
                    <Settings2 size={15} />
                  </span>
                  <div className="min-w-0">
                    <p className="examai-serif text-[15px] font-semibold text-[#0f172a]">Options avancées</p>
                    <p className="text-[10.5px] font-bold italic text-[#0f172a]/45">Personnalisation</p>
                  </div>
                </div>

                <div className="mt-4 space-y-3">
                  <Toggle
                    label="En-tête de l'établissement"
                    description="Ajoute un bloc en haut du document"
                    on={enTete}
                    onChange={setEnTete}
                  />
                  <div className="h-px bg-[#0f172a]/10" />
                  <Toggle
                    label="Pagination automatique"
                    description="Numérote les pages du document"
                    on={pagination}
                    onChange={setPagination}
                  />
                </div>

                <div className="mt-4 flex items-start gap-2 rounded-[12px] border border-[#0f172a]/15 bg-[#0f172a]/[0.02] p-3">
                  <Sparkles size={12} className="mt-0.5 shrink-0 text-[#0f172a]/50" strokeWidth={2.2} />
                  <p className="text-[11px] font-medium leading-snug text-[#0f172a]/55">
                    {format === 'impression'
                      ? 'Le PDF s\'ouvrira dans un nouvel onglet et la boîte d\'impression s\'affichera.'
                      : formatSelectionne.nature === 'texte'
                        ? 'Un choix d\'ouverture vous sera proposé après génération.'
                        : 'Le fichier sera téléchargé automatiquement une fois la génération terminée.'}
                  </p>
                </div>
              </div>

              {/* ===== AJOUT : Corrigé de l'examen — carte entièrement nouvelle ===== */}
              <div className="rounded-[24px] border border-emerald-300/70 bg-emerald-50/40 p-5">
                <div className="flex items-center gap-2.5">
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-[11px] bg-emerald-100 text-emerald-700">
                    <FileCheck2 size={15} />
                  </span>
                  <div className="min-w-0">
                    <p className="examai-serif text-[15px] font-semibold text-[#0f172a]">Corrigé de l'examen</p>
                    <p className="text-[10.5px] font-bold italic text-[#0f172a]/45">
                      Réponses, barème et explications
                    </p>
                  </div>
                </div>

                <p className="mt-3 text-[11.5px] leading-snug text-[#0f172a]/60">
                  Aperçu ci-dessous. Le PDF (réservé à l'enseignant) nécessite que l'examen
                  ait été validé à l'étape précédente.
                </p>

                {/* ===== AJOUT : aperçu du corrigé, visible immédiatement (aucun
                    appel réseau — dérivé de examen.questions déjà en mémoire) ===== */}
                <div className="mt-3 max-h-72 space-y-2 overflow-y-auto rounded-[14px] border border-emerald-200 bg-white p-3">
                  {(examen.questions || []).length === 0 ? (
                    <p className="text-[11px] italic text-[#0f172a]/40">Aucune question.</p>
                  ) : (
                    examen.questions.map((q, i) => (
                      <div key={q.id ?? i} className="rounded-[10px] border border-[#0f172a]/10 bg-[#0f172a]/[0.02] p-2.5">
                        <p className="text-[11.5px] font-semibold text-[#0f172a]">
                          {i + 1}. {q.question || <span className="italic text-[#0f172a]/40">Énoncé vide</span>}
                        </p>

                        {q.type === 'qcm' && (
                          <ul className="mt-1.5 space-y-0.5">
                            {(q.options || []).map((o, j) => (
                              <li
                                key={j}
                                className={`flex items-center gap-1.5 text-[11px] ${
                                  j === q.reponseCorrecteIndex ? 'font-bold text-emerald-700' : 'text-[#0f172a]/55'
                                }`}
                              >
                                {j === q.reponseCorrecteIndex && (
                                  <Check size={10} strokeWidth={3} className="shrink-0 text-emerald-600" />
                                )}
                                {String.fromCharCode(65 + j)}. {o}
                              </li>
                            ))}
                          </ul>
                        )}

                        {q.type === 'vrai_faux' && (
                          <p className="mt-1 text-[11px] font-bold text-emerald-700">
                            Réponse correcte : {q.reponseCorrecte ? 'Vrai' : 'Faux'}
                          </p>
                        )}

                        {(q.type === 'ouverte' || q.type === 'texte_trous') && (
                          <p className="mt-1 text-[11px] font-bold text-emerald-700">
                            Réponse attendue :{' '}
                            {q.reponseAttendue || (
                              <span className="italic font-normal text-[#0f172a]/40">Non renseignée</span>
                            )}
                          </p>
                        )}
                      </div>
                    ))
                  )}
                </div>
                {/* ===== FIN AJOUT (aperçu du corrigé) ===== */}

                {erreurCorrige && (
                  <p className="mt-2 text-[11.5px] font-medium text-[#7a0008]">{erreurCorrige}</p>
                )}

                <button
                  onClick={handleTelechargerCorrige}
                  disabled={genererCorrige}
                  className={`mt-3 flex w-full items-center justify-center gap-1.5 rounded-full bg-emerald-600 px-4 py-2.5 text-[12.5px] font-semibold text-white transition-all hover:-translate-y-0.5 hover:bg-emerald-700 active:scale-[0.985] disabled:cursor-not-allowed disabled:opacity-60 ${FOCUS_RING} ${HOVER_LIFT}`}
                >
                  {genererCorrige ? (
                    <Loader2 size={14} className="animate-spin" />
                  ) : (
                    <Download size={14} strokeWidth={2.4} />
                  )}
                  {genererCorrige ? 'Génération…' : 'Télécharger le corrigé (PDF)'}
                </button>
              </div>
              {/* ===== FIN AJOUT (carte corrigé) ===== */}
            </div>
          </div>
        )}

        {/* ===== BARRE FLOTTANTE ===== */}
        {!generation && (
          <div className="sticky bottom-4 z-20 mt-5 w-full">
            <div className="w-full overflow-hidden rounded-[20px] border border-[#0f172a]/20 bg-white shadow-[0_14px_32px_-14px_rgba(15,23,42,0.25)]">
              <div className="flex flex-col gap-3 px-4 py-3 sm:flex-row sm:items-center sm:justify-between">

                <div className="flex flex-wrap items-center gap-2 text-[12px] text-[#0f172a]/60">
                  <span className="flex items-center gap-1.5">
                    <span className="flex h-5 w-5 items-center justify-center rounded-full bg-[#0f172a]/[0.08] text-[10px] font-bold text-[#0f172a]">
                      {nbQuestions}
                    </span>
                    question{nbQuestions > 1 ? 's' : ''}
                  </span>
                  <span className="h-3 w-px bg-[#0f172a]/15" />
                  <span className="flex items-center gap-1.5">
                    <span className="flex h-5 w-5 items-center justify-center rounded-full bg-[#7a0008]/[0.08] text-[10px] font-bold text-[#7a0008]">
                      {totalPoints}
                    </span>
                    point{totalPoints > 1 ? 's' : ''}
                  </span>
                  <span className="h-3 w-px bg-[#0f172a]/15" />
                  <span className="flex items-center gap-1.5 rounded-full bg-[#0f172a]/[0.05] px-2 py-0.5 font-semibold text-[#0f172a]/70">
                    <formatSelectionne.icon size={11} />
                    {formatSelectionne.label}
                  </span>
                  {pret && (
                    <>
                      <span className="h-3 w-px bg-[#0f172a]/15" />
                      <span className="flex items-center gap-1 rounded-full bg-emerald-100 px-2 py-0.5 text-[10.5px] font-bold text-emerald-700">
                        <Check size={10} strokeWidth={3} />
                        Prêt
                      </span>
                    </>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => navigate('/wizard/validation')}
                    className={`group flex shrink-0 items-center justify-center gap-1.5 rounded-full border-2 border-[#0f172a]/25 bg-white px-4 py-2.5 text-[12.5px] font-semibold text-[#0f172a] transition-all hover:-translate-y-0.5 hover:border-[#0f172a]/60 hover:bg-[#0f172a]/[0.04] active:scale-[0.985] ${FOCUS_RING} ${HOVER_LIFT}`}
                  >
                    <ArrowLeft size={14} strokeWidth={2.4} />
                    Retour à la validation
                  </button>

                  {pret && formatSelectionne.nature === 'texte' ? (
                    <button
                      onClick={() => setShowOuvrirAvec(true)}
                      className={`group relative flex shrink-0 items-center justify-center gap-1.5 overflow-hidden rounded-full bg-[#7a0008] px-5 py-2.5 text-[12.5px] font-semibold text-white shadow-[0_1px_2px_rgba(15,23,42,0.2),0_10px_22px_-10px_rgba(122,0,8,0.55),inset_0_1px_0_rgba(255,255,255,0.15)] transition-all duration-200 hover:-translate-y-0.5 hover:bg-[#961014] active:scale-[0.985] ${FOCUS_RING}`}
                    >
                      <span className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/20 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
                      <ExternalLink size={14} strokeWidth={2.4} className="relative" />
                      <span className="relative">Ouvrir avec…</span>
                    </button>
                  ) : pret && format !== 'impression' ? (
                    <button
                      onClick={() => fichierUrl && declencherTelechargement(fichierUrl, fichierNom)}
                      className={`group relative flex shrink-0 items-center justify-center gap-1.5 overflow-hidden rounded-full bg-[#7a0008] px-5 py-2.5 text-[12.5px] font-semibold text-white shadow-[0_1px_2px_rgba(15,23,42,0.2),0_10px_22px_-10px_rgba(122,0,8,0.55),inset_0_1px_0_rgba(255,255,255,0.15)] transition-all duration-200 hover:-translate-y-0.5 hover:bg-[#961014] active:scale-[0.985] ${FOCUS_RING}`}
                    >
                      <span className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/20 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
                      <Download size={14} strokeWidth={2.4} className="relative" />
                      <span className="relative">Télécharger à nouveau</span>
                    </button>
                  ) : (
                    <button
                      onClick={handleGenerer}
                      disabled={loading}
                      className={`group relative flex shrink-0 items-center justify-center gap-1.5 overflow-hidden rounded-full bg-[#7a0008] px-5 py-2.5 text-[12.5px] font-semibold text-white shadow-[0_1px_2px_rgba(15,23,42,0.2),0_10px_22px_-10px_rgba(122,0,8,0.55),inset_0_1px_0_rgba(255,255,255,0.15)] transition-all duration-200 hover:-translate-y-0.5 hover:bg-[#961014] active:scale-[0.985] disabled:cursor-not-allowed disabled:opacity-50 disabled:hover:translate-y-0 motion-reduce:transition-none motion-reduce:hover:translate-y-0 ${FOCUS_RING}`}
                    >
                      <span className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/20 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
                      {loading ? (
                        <Loader2 size={14} className="relative animate-spin" />
                      ) : format === 'impression' ? (
                        <Printer size={14} strokeWidth={2.4} className="relative" />
                      ) : (
                        <FileText size={14} strokeWidth={2.4} className="relative" />
                      )}
                      <span className="relative">
                        {loading
                          ? 'Génération…'
                          : format === 'impression'
                            ? 'Imprimer'
                            : `Générer le ${formatSelectionne.label}`}
                      </span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* ===== MODAL OUVRIR AVEC ===== */}
      {showOuvrirAvec && contenuTexte !== null && (
        <OuvrirAvecModal
          format={format}
          formatLabel={formatSelectionne.label}
          fichierNom={fichierNom}
          contenu={contenuTexte}
          outils={OUTILS_EN_LIGNE[format] || []}
          copie={copie}
          onCopier={handleCopier}
          onFermer={() => setShowOuvrirAvec(false)}
          onTelecharger={() => {
            if (fichierUrl && fichierNom) declencherTelechargement(fichierUrl, fichierNom)
          }}
        />
      )}
    </WizardShell>
  )
}

/* ===== MODAL OUVRIR AVEC ===== */
function OuvrirAvecModal({ format, formatLabel, fichierNom, contenu, outils, copie, onCopier, onFermer, onTelecharger }) {
  const preview = contenu.length > 500 ? contenu.slice(0, 500) + '\n…' : contenu

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center p-3 sm:items-center sm:p-4">
      <div
        className="absolute inset-0 bg-[#0f172a]/50 backdrop-blur-sm"
        style={{ animation: 'examaiModalFadeIn 200ms ease-out both' }}
        onClick={onFermer}
      />

      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="ouvrir-avec-title"
        className="relative max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-[24px] border border-[#0f172a]/20 bg-white"
        style={{ animation: 'examaiModalSlideUp 240ms cubic-bezier(0.22, 1, 0.36, 1) both' }}
      >
        {/* Header */}
        <div className="sticky top-0 flex items-center justify-between gap-3 border-b border-[#0f172a]/10 bg-white/95 px-5 py-4 backdrop-blur">
          <div className="flex items-center gap-2.5">
            <span className="flex h-9 w-9 items-center justify-center rounded-[11px] bg-[#7a0008]/[0.10]">
              <ExternalLink size={15} className="text-[#7a0008]" />
            </span>
            <div className="min-w-0">
              <p id="ouvrir-avec-title" className="examai-serif text-[15px] font-semibold text-[#0f172a]">
                Comment ouvrir le {formatLabel} ?
              </p>
              <p className="truncate text-[11px] font-bold italic text-[#0f172a]/50">
                {fichierNom}
              </p>
            </div>
          </div>
          <button
            onClick={onFermer}
            aria-label="Fermer"
            className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-[#0f172a]/60 transition-colors hover:bg-[#0f172a]/[0.06]"
          >
            <X size={14} />
          </button>
        </div>

        {/* Body */}
        <div className="space-y-4 p-5">

          {/* Info */}
          <div className="flex items-start gap-2 rounded-[12px] border border-amber-300 bg-amber-50/70 p-3">
            <AlertTriangle size={14} className="mt-0.5 shrink-0 text-amber-700" />
            <p className="text-[12px] font-medium leading-snug text-amber-900">
              Les fichiers <span className="font-bold">.{format}</span> ne sont pas associés par défaut à une application. Windows peut les ouvrir dans Word, mais ce n'est pas idéal.
            </p>
          </div>

          {/* Actions principales */}
          <div className="grid gap-2 sm:grid-cols-2">
            <button
              onClick={onTelecharger}
              className={`group flex items-center gap-3 rounded-[14px] border border-[#0f172a]/20 bg-white p-3.5 text-left transition-all hover:-translate-y-0.5 hover:border-[#0f172a]/50 hover:shadow-[0_8px_20px_-10px_rgba(15,23,42,0.2)] ${FOCUS_RING} ${HOVER_LIFT}`}
            >
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-[11px] bg-[#0f172a]/[0.08] text-[#0f172a]">
                <Download size={16} strokeWidth={2.4} />
              </span>
              <span className="min-w-0">
                <span className="block text-[13px] font-bold text-[#0f172a]">Télécharger</span>
                <span className="mt-0.5 block text-[11px] italic text-[#0f172a]/50">
                  Enregistrer sur mon ordinateur
                </span>
              </span>
            </button>

            <button
              onClick={onCopier}
              className={`group flex items-center gap-3 rounded-[14px] border p-3.5 text-left transition-all hover:-translate-y-0.5 hover:shadow-[0_8px_20px_-10px_rgba(15,23,42,0.2)] ${FOCUS_RING} ${HOVER_LIFT} ${
                copie
                  ? 'border-emerald-500 bg-emerald-50/40'
                  : 'border-[#0f172a]/20 bg-white hover:border-[#0f172a]/50'
              }`}
            >
              <span className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-[11px] ${
                copie ? 'bg-emerald-100 text-emerald-600' : 'bg-[#0f172a]/[0.08] text-[#0f172a]'
              }`}>
                {copie ? <Check size={16} strokeWidth={3} /> : <Copy size={16} strokeWidth={2.4} />}
              </span>
              <span className="min-w-0">
                <span className={`block text-[13px] font-bold ${copie ? 'text-emerald-700' : 'text-[#0f172a]'}`}>
                  {copie ? 'Copié !' : 'Copier le contenu'}
                </span>
                <span className="mt-0.5 block text-[11px] italic text-[#0f172a]/50">
                  Coller dans un éditeur
                </span>
              </span>
            </button>
          </div>

          {/* Outils en ligne */}
          {outils.length > 0 && (
            <div>
              <p className="mb-2 flex items-center gap-2 text-[11px] font-bold uppercase tracking-wider text-[#0f172a]/50">
                <Globe size={11} />
                Ouvrir dans un outil en ligne
              </p>
              <div className="grid gap-2 sm:grid-cols-3">
                {outils.map((outil) => {
                  const Icon = outil.icon
                  return (
                    <a
                      key={outil.label}
                      href={outil.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`group flex items-center justify-between gap-2 rounded-[12px] border border-[#0f172a]/15 bg-white px-3 py-2.5 text-[12px] font-semibold text-[#0f172a]/80 transition-all hover:-translate-y-0.5 hover:border-[#7a0008]/40 hover:text-[#7a0008] ${FOCUS_RING} ${HOVER_LIFT}`}
                    >
                      <span className="flex items-center gap-2">
                        <Icon size={12} strokeWidth={2.4} />
                        {outil.label}
                      </span>
                      <ExternalLink size={10} className="opacity-40 transition-opacity group-hover:opacity-100" />
                    </a>
                  )
                })}
              </div>
              <p className="mt-2 text-[10.5px] italic text-[#0f172a]/45">
                Copiez d'abord le contenu, puis collez-le dans l'outil ouvert.
              </p>
            </div>
          )}

          {/* Aperçu du contenu */}
          <div>
            <p className="mb-2 flex items-center gap-2 text-[11px] font-bold uppercase tracking-wider text-[#0f172a]/50">
              <Eye size={11} />
              Aperçu du contenu
            </p>
            <pre className="max-h-48 overflow-auto rounded-[12px] border border-[#0f172a]/15 bg-[#0f172a]/[0.03] p-3 font-mono text-[11px] leading-relaxed text-[#0f172a]/80">
              {preview}
            </pre>
          </div>
        </div>

        {/* Footer */}
        <div className="flex justify-end gap-2 border-t border-[#0f172a]/10 bg-[#0f172a]/[0.02] p-4">
          <button
            onClick={onFermer}
            className={`rounded-full border border-[#0f172a]/20 bg-white px-5 py-2.5 text-[12.5px] font-semibold text-[#0f172a] transition-all hover:-translate-y-0.5 hover:border-[#0f172a]/40 ${FOCUS_RING} ${HOVER_LIFT}`}
          >
            Fermer
          </button>
        </div>
      </div>
    </div>
  )
}

/* ===== TOGGLE ===== */
function Toggle({ label, description, on, onChange }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      onClick={() => onChange(!on)}
      className={`group flex w-full items-center justify-between gap-3 text-left ${FOCUS_RING}`}
    >
      <span className="min-w-0">
        <span className="block text-[13px] font-semibold text-[#0f172a]">{label}</span>
        {description && (
          <span className="mt-0.5 block text-[11px] italic text-[#0f172a]/50">{description}</span>
        )}
      </span>
      <span
        className={`relative flex h-6 w-11 shrink-0 items-center rounded-full transition-colors duration-200 ${
          on ? 'bg-[#7a0008]' : 'bg-[#0f172a]/[0.15]'
        }`}
      >
        <span
          className={`absolute h-5 w-5 rounded-full bg-white shadow-[0_1px_3px_rgba(15,23,42,0.25)] transition-transform duration-200 ${
            on ? 'translate-x-[22px]' : 'translate-x-0.5'
          }`}
        />
      </span>
    </button>
  )
}

/* ===== LOADER ===== */
function GenerationLoader({ formatLabel = 'PDF' }) {
  return (
    <div className="relative flex min-h-[420px] flex-col items-center justify-center gap-8 overflow-hidden rounded-[24px] border border-[#0f172a]/20 bg-white p-10">

      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="examai-scan absolute left-0 right-0 h-32 bg-gradient-to-b from-transparent via-[#7a0008]/[0.06] to-transparent" />
      </div>

      <div className="relative flex h-40 w-40 items-center justify-center">
        <div className="examai-orbit-slow absolute inset-0 rounded-full border-2 border-dashed border-[#0f172a]/20">
          <span className="absolute -top-1 left-1/2 h-2 w-2 -translate-x-1/2 rounded-full bg-[#0f172a]/40" />
          <span className="absolute -bottom-1 left-1/2 h-2 w-2 -translate-x-1/2 rounded-full bg-[#0f172a]/40" />
        </div>

        <div className="examai-orbit absolute inset-4 rounded-full border-2 border-[#7a0008]/20">
          <span className="absolute -top-1.5 left-1/2 h-2.5 w-2.5 -translate-x-1/2 rounded-full bg-[#7a0008] shadow-[0_0_10px_rgba(122,0,8,0.5)]" />
        </div>

        <div className="examai-orbit-pulse absolute inset-10 rounded-full border border-[#7a0008]/30 bg-[#7a0008]/[0.04]" />

        <div className="relative flex h-16 w-16 items-center justify-center rounded-full bg-[#7a0008] shadow-[0_8px_24px_-6px_rgba(122,0,8,0.6)]">
          <FileText size={24} className="text-white" strokeWidth={2} />
        </div>
      </div>

      <div className="relative flex flex-col items-center gap-2 text-center">
        <h3 className="examai-serif text-[18px] font-semibold text-[#0f172a]">
          Génération en cours
        </h3>
        <p className="flex items-center gap-1 text-[13px] font-medium italic text-[#0f172a]/55">
          Préparation du {formatLabel}
          <span className="examai-dot-1 inline-block h-1 w-1 rounded-full bg-[#0f172a]/60" />
          <span className="examai-dot-2 inline-block h-1 w-1 rounded-full bg-[#0f172a]/60" />
          <span className="examai-dot-3 inline-block h-1 w-1 rounded-full bg-[#0f172a]/60" />
        </p>
      </div>

      <ul className="relative w-full max-w-sm space-y-1.5">
        {ETAPES_GENERATION.map((etape, idx) => {
          const Icon = etape.icon
          return (
            <li
              key={etape.label}
              className="examai-fade-in-up flex items-center gap-2.5 rounded-[10px] border border-[#0f172a]/10 bg-[#0f172a]/[0.02] px-3 py-2"
              style={{ animationDelay: `${idx * 0.12}s` }}
            >
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-white ring-1 ring-[#0f172a]/15">
                <Icon size={12} className="text-[#0f172a]/70" strokeWidth={2.2} />
              </span>
              <span className="text-[12px] font-medium text-[#0f172a]/70">
                {etape.label}
              </span>
              <span className="ml-auto flex h-1.5 w-1.5">
                <span className="examai-dot-1 h-full w-full rounded-full bg-[#7a0008]" />
              </span>
            </li>
          )
        })}
      </ul>

    </div>
  )
}