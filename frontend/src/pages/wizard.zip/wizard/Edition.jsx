import { useState, useEffect, useMemo, useRef } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import {
  Pencil, Copy, Trash2, Plus, Loader2, AlertTriangle, Check,
  ListChecks, ArrowLeft, ArrowRight, FileEdit, Search, X,
  ArrowUp, ArrowDown, Save, Filter, Eye, Clock, AlertCircle,
  Sparkles, GripVertical, ChevronDown,
} from 'lucide-react'
import WizardShell from '../../components/WizardShell.jsx'
import { useWizard } from '../../context/WizardContext.jsx'

const TYPE_LABEL = {
  qcm: 'QCM',
  vrai_faux: 'Vrai / Faux',
  ouverte: 'Ouverte',
  texte_trous: 'Texte à trous',
  // NOUVEAU (voir models.py / quiz_engine.py cote backend)
  association: 'Association',
  remise_en_ordre: 'Remise en ordre',
  tri: 'Tri / Classement',
  calcul: 'Calcul',
  legende: 'Légende',
  dictee: 'Dictée',
  redaction: 'Rédaction',
}

const TYPE_COLOR = {
  qcm: { bg: 'bg-[#0f172a]/[0.08]', text: 'text-[#0f172a]' },
  vrai_faux: { bg: 'bg-[#7a0008]/[0.08]', text: 'text-[#7a0008]' },
  ouverte: { bg: 'bg-emerald-500/[0.10]', text: 'text-emerald-700' },
  texte_trous: { bg: 'bg-amber-500/[0.10]', text: 'text-amber-700' },
  // NOUVEAU
  association: { bg: 'bg-blue-500/[0.10]', text: 'text-blue-700' },
  remise_en_ordre: { bg: 'bg-purple-500/[0.10]', text: 'text-purple-700' },
  tri: { bg: 'bg-orange-500/[0.10]', text: 'text-orange-700' },
  calcul: { bg: 'bg-cyan-500/[0.10]', text: 'text-cyan-700' },
  legende: { bg: 'bg-teal-500/[0.10]', text: 'text-teal-700' },
  dictee: { bg: 'bg-indigo-500/[0.10]', text: 'text-indigo-700' },
  redaction: { bg: 'bg-pink-500/[0.10]', text: 'text-pink-700' },
}

const WIZARD_STEPS = [
  { n: 1, label: 'Sélection' },
  { n: 2, label: 'Édition' },
  { n: 3, label: 'Validation' },
  { n: 4, label: 'Export' },
]
const CURRENT_STEP = 2

const FOCUS_RING = 'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0f172a]/35 focus-visible:ring-offset-2'
const HOVER_LIFT = 'motion-reduce:transition-none motion-reduce:hover:translate-y-0'

// ✅ Boutons d'action gris, sans bordure, visibles uniquement au survol
const ACTION_BTN = 'flex h-8 w-8 items-center justify-center rounded-full text-[#0f172a]/50 transition-all hover:bg-[#0f172a]/[0.08] hover:text-[#0f172a] disabled:opacity-30 disabled:cursor-not-allowed disabled:hover:bg-transparent disabled:hover:text-[#0f172a]/50'
const ACTION_BTN_DANGER = 'flex h-8 w-8 items-center justify-center rounded-full text-[#0f172a]/50 transition-all hover:bg-red-50 hover:text-red-600 disabled:opacity-30 disabled:cursor-not-allowed'

function questionComplete(q) {
  if (!q.question?.trim()) return false
  if (q.type === 'qcm') {
    return q.options?.length >= 2
      && q.options.every((o) => o?.trim())
      && q.reponseCorrecteIndex != null
      && q.reponseCorrecteIndex >= 0
  }
  if (q.type === 'vrai_faux') return q.reponseCorrecte === true || q.reponseCorrecte === false
  if (q.type === 'ouverte') return Boolean(q.reponseAttendue?.trim())
  if (q.type === 'texte_trous') return Boolean(q.reponseAttendue?.trim())
  // NOUVEAU (voir models.py cote backend pour la forme exacte de chaque type)
  if (q.type === 'association') {
    return (q.colonne_gauche?.length || 0) >= 2
      && (q.colonne_droite?.length || 0) >= 2
      && q.colonne_gauche.every((v) => v?.trim())
      && q.colonne_droite.every((v) => v?.trim())
      && q.reponseCorrecte?.length === q.colonne_gauche.length
      && q.reponseCorrecte.every((i) => i != null && i >= 0)
  }
  if (q.type === 'remise_en_ordre') {
    return (q.elements?.length || 0) >= 2
      && q.elements.every((v) => v?.trim())
      && q.reponseCorrecte?.length === q.elements.length
  }
  if (q.type === 'tri') {
    return (q.categories?.length || 0) >= 2
      && (q.elements?.length || 0) >= 2
      && q.categories.every((v) => v?.trim())
      && q.elements.every((v) => v?.trim())
      && q.reponseCorrecte?.length === q.elements.length
      && q.reponseCorrecte.every((i) => i != null && i >= 0)
  }
  if (q.type === 'calcul') return q.reponseAttendue !== undefined && q.reponseAttendue !== null && q.reponseAttendue !== ''
  if (q.type === 'legende') {
    return Boolean(q.image?.url || q.image?.description)
      && (q.reponseCorrecte?.length || 0) >= 1
      && q.reponseCorrecte.every((v) => v?.trim())
  }
  if (q.type === 'dictee') return Boolean(q.texte_dictee?.trim())
  if (q.type === 'redaction') return true // pas de reponse unique a verifier
  return true
}

export default function Edition() {
  const navigate = useNavigate()
  const {
    examen,
    updateQuestion,
    removeQuestion,
    duplicateQuestion,
    addQuestion,
    sauvegarderQuestions,
    reordonnerQuestions,
    setQuestions,
    loading,
    error,
  } = useWizard()

  const questions = examen.questions || []
  const [selected, setSelected] = useState(questions[0]?.id)

  const [recherche, setRecherche] = useState('')
  const [filtreType, setFiltreType] = useState('all')
  const [filtreOuvert, setFiltreOuvert] = useState(false)
  const [showApercu, setShowApercu] = useState(false)
  const [autosaveStatut, setAutosaveStatut] = useState('idle')
  const [showShortcuts, setShowShortcuts] = useState(false)
  const filtreRef = useRef(null)

  const [questionASupprimer, setQuestionASupprimer] = useState(null)

  const totalPoints = questions.reduce((sum, q) => sum + (Number(q.points) || 0), 0)

  const questionsIncompletes = useMemo(
    () => questions.filter((q) => !questionComplete(q)),
    [questions]
  )

  const questionsFiltrees = useMemo(() => {
    const q = recherche.trim().toLowerCase()
    return questions.filter((question, i) => {
      const matchRecherche = !q
        || question.question?.toLowerCase().includes(q)
        || `q${i + 1}`.includes(q)
        || String(i + 1).includes(q)
      const matchType = filtreType === 'all' || question.type === filtreType
      return matchRecherche && matchType
    })
  }, [questions, recherche, filtreType])

  useEffect(() => {
    if (!examen.id) return
    setAutosaveStatut('saving')
    const timer = setTimeout(() => setAutosaveStatut('saved'), 800)
    return () => clearTimeout(timer)
  }, [examen.questions, examen.id])

  useEffect(() => {
    if (!filtreOuvert) return
    function handleClick(e) {
      if (filtreRef.current && !filtreRef.current.contains(e.target)) {
        setFiltreOuvert(false)
      }
    }
    document.addEventListener('mousedown', handleClick)
    return () => document.removeEventListener('mousedown', handleClick)
  }, [filtreOuvert])

  useEffect(() => {
    function handleKeyDown(e) {
      if (questionASupprimer || showApercu || showShortcuts) return

      if ((e.ctrlKey || e.metaKey) && e.key === 's') {
        e.preventDefault()
        sauvegarderQuestions?.().catch(() => {})
      }
      if ((e.ctrlKey || e.metaKey) && e.key === 'd' && selected) {
        e.preventDefault()
        duplicateQuestion?.(selected)
      }
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        e.preventDefault()
        handleVerifier()
      }
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault()
        document.getElementById('search-input')?.focus()
      }
      if (e.key === '?' && !e.target.matches('input, textarea')) {
        setShowShortcuts((v) => !v)
      }
    }
    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [selected, duplicateQuestion, sauvegarderQuestions, questionASupprimer, showApercu, showShortcuts])

  // ===== AJOUT : affiche automatiquement l'aperçu (examen + corrigé, déjà
  // fourni par ApercuModal plus bas, qui surligne la bonne réponse de
  // chaque question) dès l'arrivée sur l'édition — sans ça il fallait
  // cliquer sur "Aperçu" pour voir la correction. N'ouvre rien d'autre,
  // ne touche à aucun state existant en dehors de showApercu lui-même.
  useEffect(() => {
    if (examen.id && questions.length > 0) {
      setShowApercu(true)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [examen.id])
  // ===== FIN AJOUT =====

  function scrollTo(id) {
    setSelected(id)
    document.getElementById(`question-${id}`)?.scrollIntoView({ behavior: 'smooth', block: 'center' })
  }

  function handleAjouter() {
    const id = addQuestion?.()
    if (id) requestAnimationFrame(() => scrollTo(id))
  }

  function handleSupprimer(id) {
    const q = questions.find((x) => x.id === id)
    if (q) {
      setQuestionASupprimer({
        id,
        index: questions.findIndex((x) => x.id === id),
        question: q,
      })
    }
  }

  function confirmerSuppression() {
    if (questionASupprimer) {
      removeQuestion?.(questionASupprimer.id)
      setQuestionASupprimer(null)
    }
  }

  function deplacer(fromIndex, toIndex) {
    if (fromIndex === toIndex) return
    if (fromIndex < 0 || toIndex < 0) return
    if (fromIndex >= questions.length || toIndex >= questions.length) return

    if (typeof reordonnerQuestions === 'function') {
      try {
        reordonnerQuestions(fromIndex, toIndex)
        return
      } catch (e) {
        console.warn('reordonnerQuestions(from, to) a échoué', e)
      }
    }

    if (typeof setQuestions === 'function') {
      const qs = [...questions]
      const [moved] = qs.splice(fromIndex, 1)
      qs.splice(toIndex, 0, moved)
      setQuestions(qs)
      return
    }

    if (typeof updateQuestion === 'function') {
      const a = questions[fromIndex]
      const b = questions[toIndex]
      if (!a || !b) return
      const aData = { ...a }; delete aData.id
      const bData = { ...b }; delete bData.id
      updateQuestion(a.id, bData)
      updateQuestion(b.id, aData)
      return
    }

    console.error('Impossible de réordonner')
  }

  function handleMonter(id) {
    const idx = questions.findIndex((q) => q.id === id)
    if (idx > 0) deplacer(idx, idx - 1)
  }

  function handleDescendre(id) {
    const idx = questions.findIndex((q) => q.id === id)
    if (idx !== -1 && idx < questions.length - 1) deplacer(idx, idx + 1)
  }

  async function handleVerifier() {
    try {
      await sauvegarderQuestions?.()
      navigate('/wizard/validation')
    } catch {}
  }

  const nbTypesDispo = [...new Set(questions.map((q) => q.type))]

  if (!examen.id) {
    return (
      <WizardShell step={2} hideStepper>
        <div className="mx-auto max-w-lg py-14 text-center">
          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-[#7a0008]/[0.08] text-[#7a0008]">
            <FileEdit size={22} />
          </div>
          <h1 className="examai-serif text-[20px] font-semibold text-[#0f172a]">Aucun examen en cours</h1>
          <p className="mt-2 text-[13.5px] font-bold italic text-[#0f172a]/55">
            Retournez à l'étape 1 pour générer un examen avant de pouvoir le modifier ici.
          </p>
          <Link
            to="/wizard/selection"
            className={`mt-5 inline-flex items-center gap-2 rounded-full bg-[#7a0008] px-6 py-3 text-[13.5px] font-semibold text-white shadow-[0_1px_2px_rgba(15,23,42,0.2),0_10px_22px_-8px_rgba(122,0,8,0.5)] transition-all hover:-translate-y-0.5 active:scale-[0.985] ${FOCUS_RING}`}
          >
            Aller à la sélection <ArrowRight size={15} />
          </Link>
        </div>
      </WizardShell>
    )
  }

  return (
    <WizardShell step={2} hideStepper>
      <style>{`
        .examai-underline-wave {
          background-color: rgba(122,0,8,0.12);
          background-repeat: no-repeat;
          background-size: 100% 0.35em;
          background-position: 0 88%;
          padding: 0 0.15em;
        }
        @keyframes examaiPulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }
        .examai-pulse { animation: examaiPulse 1.6s ease-in-out infinite; }

        @keyframes examaiModalFadeIn { from { opacity: 0 } to { opacity: 1 } }
        @keyframes examaiModalSlideUp {
          from { opacity: 0; transform: translateY(16px) scale(0.97); }
          to   { opacity: 1; transform: translateY(0) scale(1); }
        }

        @media (prefers-reduced-motion: reduce) {
          .examai-pulse { animation: none !important; }
        }
      `}</style>

      <div className="w-full max-w-full overflow-x-hidden">

        {/* ===== EN-TÊTE ===== */}
        <div className="relative mb-6 w-full overflow-hidden rounded-[28px] border border-[#0f172a]/20 bg-white p-6 sm:p-8">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div className="min-w-0 flex-1">
              <h1 className="examai-serif text-[30px] sm:text-[40px] lg:text-[42px] font-semibold tracking-[-0.025em] text-[#0f172a] leading-[1.15]">
                Modifier{' '}
                <span className="text-[#7a0008] relative">
                  <span className="examai-underline-wave">L'examen.</span>
                </span>
              </h1>
              <p className="examai-serif mt-3 text-[14px] sm:text-[15px] font-normal italic leading-[1.6] text-[#0f172a]/75">
                Ajustez les questions, les réponses et le barème avant de passer à la validation.
              </p>
            </div>

            {/* Indicateur autosave — bordure verte statique */}
            <div
              className={`flex shrink-0 items-center gap-2 rounded-full border-2 px-3 py-1.5 text-[11.5px] font-semibold transition-all ${
                autosaveStatut === 'saved'
                  ? 'border-emerald-500 bg-emerald-50/40'
                  : autosaveStatut === 'saving'
                    ? 'border-amber-300 bg-white'
                    : 'border-[#0f172a]/15 bg-white'
              }`}
            >
              {autosaveStatut === 'saving' ? (
                <>
                  <span className="examai-pulse h-2 w-2 rounded-full bg-amber-500" />
                  <span className="text-[#0f172a]/60">Enregistrement…</span>
                </>
              ) : autosaveStatut === 'saved' ? (
                <>
                  <Check size={12} className="text-emerald-600" strokeWidth={3} />
                  <span className="font-bold text-emerald-700">Brouillon enregistré</span>
                </>
              ) : (
                <>
                  <Save size={12} className="text-[#0f172a]/40" />
                  <span className="text-[#0f172a]/50">Prêt</span>
                </>
              )}
            </div>
          </div>
        </div>

        {/* ===== ERREUR ===== */}
        {error && (
          <div role="alert" className="mb-5 flex items-start gap-3 rounded-[16px] border border-[#7a0008]/40 bg-[#0f172a]/[0.035] p-4 text-[13px] text-[#0f172a]">
            <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[#7a0008]/10">
              <AlertTriangle size={14} className="text-[#7a0008]" />
            </span>
            <span className="min-w-0 break-words pt-0.5 font-medium">{error}</span>
          </div>
        )}

        {/* ===== AVERTISSEMENT QUESTIONS INCOMPLÈTES ===== */}
        {questionsIncompletes.length > 0 && (
          <div className="mb-5 flex items-start gap-3 rounded-[16px] border border-amber-300 bg-amber-50/70 p-4 text-[13px] text-amber-900">
            <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-amber-200">
              <AlertCircle size={14} className="text-amber-700" />
            </span>
            <div className="min-w-0 flex-1">
              <p className="font-bold">
                {questionsIncompletes.length} question{questionsIncompletes.length > 1 ? 's' : ''} incomplète{questionsIncompletes.length > 1 ? 's' : ''}
              </p>
              <p className="mt-0.5 text-[12px] font-bold italic text-amber-800/80">
                Vérifiez l'énoncé, les options et la bonne réponse avant de valider.
              </p>
            </div>
          </div>
        )}

        {/* ===== Étapes du parcours ===== */}
        <div className="mb-5 flex items-center rounded-[20px] border border-[#0f172a]/20 bg-white px-5 py-4" role="list" aria-label="Étapes de création de l'examen">
          {WIZARD_STEPS.map((s, i) => {
            const active = s.n === CURRENT_STEP
            const done = s.n < CURRENT_STEP
            return (
              <div key={s.n} role="listitem" className="flex flex-1 items-center last:flex-none">
                <div className="flex items-center gap-2.5">
                  <span className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-[13px] font-bold transition-colors ${
                    active
                      ? 'bg-[#7a0008] text-white shadow-[0_6px_14px_-4px_rgba(122,0,8,0.5)]'
                      : done
                        ? 'bg-[#7a0008]/10 text-[#7a0008]'
                        : 'bg-[#0f172a]/[0.06] text-[#0f172a]/40'
                  }`}>
                    {done ? <Check size={14} strokeWidth={3} /> : s.n}
                  </span>
                  <span className={`whitespace-nowrap text-[13px] font-semibold ${
                    active ? 'text-[#7a0008]' : done ? 'text-[#0f172a]/70' : 'text-[#0f172a]/40'
                  }`}>{s.label}</span>
                </div>
                {i < WIZARD_STEPS.length - 1 && (
                  <span className={`mx-3 h-px flex-1 rounded-full ${done ? 'bg-[#7a0008]/25' : 'bg-[#0f172a]/10'}`} />
                )}
              </div>
            )
          })}
        </div>

        {/* ===== CONTENU ===== */}
        <div className="grid gap-5 lg:grid-cols-[280px_1fr] lg:items-start">

          <aside className="h-fit rounded-[24px] border border-[#0f172a]/20 bg-white p-4 lg:sticky lg:top-6">

            <div className="mb-3 flex items-center justify-between gap-2">
              <div className="flex items-center gap-3">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-[11px] bg-[#7a0008]/[0.08] text-[#7a0008]">
                  <ListChecks size={15} />
                </span>
                <p className="examai-serif text-[14.5px] font-semibold text-[#0f172a]">
                  Questions <span className="text-[#7a0008]/60">({questions.length})</span>
                </p>
              </div>
            </div>

            <div className="relative mb-2">
              <Search size={14} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-[#0f172a]" strokeWidth={2.4} />
              <input
                id="search-input"
                type="text"
                value={recherche}
                onChange={(e) => setRecherche(e.target.value)}
                placeholder="Rechercher… (Ctrl+K)"
                aria-label="Rechercher une question"
                className={`w-full rounded-[12px] border-2 border-[#0f172a] bg-white py-2 pl-9 pr-8 text-[12.5px] text-[#0f172a] placeholder:text-[#0f172a]/40 focus:border-[#0f172a] focus:outline-none focus:shadow-[0_0_0_4px_rgba(15,23,42,0.15)] ${FOCUS_RING}`}
              />
              {recherche && (
                <button
                  type="button"
                  onClick={() => setRecherche('')}
                  aria-label="Effacer"
                  className="absolute right-2 top-1/2 -translate-y-1/2 flex h-5 w-5 items-center justify-center rounded-full text-[#0f172a] hover:bg-[#0f172a]/[0.10]"
                >
                  <X size={11} strokeWidth={2.6} />
                </button>
              )}
            </div>

            <div ref={filtreRef} className="relative mb-3">
              <button
                type="button"
                onClick={() => setFiltreOuvert((v) => !v)}
                className={`flex w-full items-center justify-between gap-2 rounded-[12px] border border-[#0f172a]/20 bg-white px-3 py-2 text-[12.5px] font-semibold text-[#0f172a]/80 transition-all hover:border-[#0f172a]/40 ${FOCUS_RING}`}
              >
                <span className="flex items-center gap-2">
                  <Filter size={12} strokeWidth={2.4} />
                  {filtreType === 'all' ? 'Tous les types' : TYPE_LABEL[filtreType]}
                </span>
                <ChevronDown size={12} className={`transition-transform ${filtreOuvert ? 'rotate-180' : ''}`} />
              </button>

              {filtreOuvert && (
                <div className="absolute left-0 right-0 top-[calc(100%+6px)] z-30 overflow-hidden rounded-[14px] border border-[#0f172a]/20 bg-white shadow-[0_16px_32px_-12px_rgba(15,23,42,0.25)]">
                  <div className="p-1.5">
                    <button
                      type="button"
                      onClick={() => { setFiltreType('all'); setFiltreOuvert(false) }}
                      className={`flex w-full items-center justify-between rounded-[10px] px-2.5 py-2 text-left text-[12px] font-semibold transition-colors ${
                        filtreType === 'all' ? 'bg-[#0f172a]/[0.08] text-[#0f172a]' : 'text-[#0f172a]/70 hover:bg-[#0f172a]/[0.04]'
                      }`}
                    >
                      Tous les types
                      {filtreType === 'all' && <Check size={12} strokeWidth={3} />}
                    </button>
                    {nbTypesDispo.map((t) => (
                      <button
                        key={t}
                        type="button"
                        onClick={() => { setFiltreType(t); setFiltreOuvert(false) }}
                        className={`flex w-full items-center justify-between rounded-[10px] px-2.5 py-2 text-left text-[12px] font-semibold transition-colors ${
                          filtreType === t ? 'bg-[#0f172a]/[0.08] text-[#0f172a]' : 'text-[#0f172a]/70 hover:bg-[#0f172a]/[0.04]'
                        }`}
                      >
                        {TYPE_LABEL[t]}
                        {filtreType === t && <Check size={12} strokeWidth={3} />}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {questions.length === 0 ? (
              <p className="rounded-[14px] border border-dashed border-[#7a0008]/25 bg-[#0f172a]/[0.03] px-3 py-4 text-center text-[12px] font-bold italic text-[#0f172a]/50">
                Aucune question pour l'instant
              </p>
            ) : questionsFiltrees.length === 0 ? (
              <p className="rounded-[14px] border border-dashed border-[#0f172a]/25 bg-[#0f172a]/[0.03] px-3 py-4 text-center text-[12px] font-bold italic text-[#0f172a]/50">
                Aucun résultat
              </p>
            ) : (
              <ul className="max-h-[400px] space-y-1 overflow-y-auto pr-1">
                {questionsFiltrees.map((q) => {
                  const realIndex = questions.findIndex((x) => x.id === q.id)
                  const active = selected === q.id
                  const complete = questionComplete(q)
                  const tc = TYPE_COLOR[q.type] || TYPE_COLOR.qcm
                  return (
                    <li key={q.id}>
                      <button
                        onClick={() => scrollTo(q.id)}
                        className={`flex w-full items-center justify-between gap-2 rounded-[12px] px-3 py-2 text-left text-[13px] transition-colors ${FOCUS_RING} ${
                          active
                            ? 'bg-[#7a0008]/[0.08] font-bold text-[#7a0008]'
                            : 'text-[#0f172a]/60 hover:bg-[#0f172a]/[0.05] hover:text-[#0f172a]'
                        }`}
                      >
                        <span className="flex min-w-0 items-center gap-2">
                          <span className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-[10px] font-bold ${
                            active ? 'bg-[#7a0008] text-white' : 'bg-[#0f172a]/[0.08] text-[#0f172a]/60'
                          }`}>{realIndex + 1}</span>
                          <span className="truncate max-w-[120px]">
                            {q.question?.trim() || `Question ${realIndex + 1}`}
                          </span>
                        </span>
                        <span className={`shrink-0 rounded-full px-1.5 py-0.5 text-[9.5px] font-bold ${tc.bg} ${tc.text}`}>
                          {complete ? TYPE_LABEL[q.type] : '⚠'}
                        </span>
                      </button>
                    </li>
                  )
                })}
              </ul>
            )}

            <button
              type="button"
              onClick={() => setShowShortcuts((v) => !v)}
              className={`mt-3 flex w-full items-center justify-center gap-1.5 rounded-[10px] border border-dashed border-[#0f172a]/40 bg-white py-2 text-[11px] font-bold text-[#0f172a] transition-colors hover:border-[#0f172a] hover:bg-[#0f172a]/[0.04] ${FOCUS_RING}`}
            >
              <Sparkles size={11} className="text-[#0f172a]" strokeWidth={2.4} />
              Raccourcis clavier ( ? )
            </button>
          </aside>

          <div className="space-y-4">
            {questionsFiltrees.length === 0 && questions.length > 0 ? (
              <div className="rounded-[20px] border border-dashed border-[#0f172a]/25 bg-white py-14 text-center">
                <p className="text-[13.5px] font-bold italic text-[#0f172a]/50">
                  Aucune question ne correspond à votre recherche
                </p>
              </div>
            ) : (
              questionsFiltrees.map((q) => {
                const realIndex = questions.findIndex((x) => x.id === q.id)
                return (
                  <QuestionCard
                    key={q.id}
                    index={realIndex}
                    total={questions.length}
                    question={q}
                    onChange={(patch) => updateQuestion(q.id, patch)}
                    onDuplicate={() => duplicateQuestion(q.id)}
                    onDelete={() => handleSupprimer(q.id)}
                    onUp={() => handleMonter(q.id)}
                    onDown={() => handleDescendre(q.id)}
                    canUp={realIndex > 0}
                    canDown={realIndex < questions.length - 1}
                  />
                )
              })
            )}

            <button
              onClick={handleAjouter}
              className={`flex w-full items-center justify-center gap-2 rounded-[16px] border-2 border-dashed border-[#0f172a]/30 bg-white py-3.5 text-[13.5px] font-bold text-[#0f172a]/60 transition-all hover:-translate-y-0.5 hover:border-[#0f172a]/60 hover:text-[#0f172a] ${FOCUS_RING} ${HOVER_LIFT}`}
            >
              <Plus size={16} strokeWidth={2.4} /> Ajouter une question
            </button>
          </div>
        </div>

        {/* ===== BARRE FLOTTANTE COMPACTE ===== */}
        <div className="sticky bottom-4 z-20 mt-5 w-full">
          <div className="w-full overflow-hidden rounded-[20px] border border-[#0f172a]/20 bg-white shadow-[0_14px_32px_-14px_rgba(15,23,42,0.25)]">
            <div className="flex flex-col gap-3 px-4 py-3 sm:flex-row sm:items-center sm:justify-between">

              <div className="flex flex-wrap items-center gap-2 text-[12px] text-[#0f172a]/60">
                <span className="flex items-center gap-1.5">
                  <span className="flex h-5 w-5 items-center justify-center rounded-full bg-[#0f172a]/[0.08] text-[10px] font-bold text-[#0f172a]">
                    {questions.length}
                  </span>
                  question{questions.length > 1 ? 's' : ''}
                </span>
                <span className="h-3 w-px bg-[#0f172a]/15" />
                <span className="flex items-center gap-1.5">
                  <span className="flex h-5 w-5 items-center justify-center rounded-full bg-[#7a0008]/[0.08] text-[10px] font-bold text-[#7a0008]">
                    {totalPoints}
                  </span>
                  point{totalPoints > 1 ? 's' : ''}
                </span>
                {questionsIncompletes.length > 0 && (
                  <>
                    <span className="h-3 w-px bg-[#0f172a]/15" />
                    <span className="flex items-center gap-1 rounded-full bg-amber-100 px-2 py-0.5 text-[10.5px] font-bold text-amber-800">
                      <AlertCircle size={10} />
                      {questionsIncompletes.length} incomplète{questionsIncompletes.length > 1 ? 's' : ''}
                    </span>
                  </>
                )}
              </div>

              <div className="flex items-center gap-2">

                {/* Bouton Aperçu — ROUGE */}
                <button
                  type="button"
                  onClick={() => setShowApercu(true)}
                  className={`flex items-center gap-1.5 rounded-full border-2 border-[#7a0008]/30 bg-white px-3.5 py-2 text-[12px] font-semibold text-[#7a0008] transition-all hover:-translate-y-0.5 hover:border-[#7a0008] hover:bg-[#7a0008]/[0.04] hover:shadow-[0_4px_12px_-6px_rgba(122,0,8,0.25)] ${FOCUS_RING} ${HOVER_LIFT}`}
                >
                  <Eye size={13} className="text-[#7a0008]" strokeWidth={2.2} />
                  Aperçu
                </button>

                {/* Bouton Vérifier */}
                <button
                  onClick={handleVerifier}
                  disabled={loading}
                  className={`group relative flex shrink-0 items-center justify-center gap-1.5 overflow-hidden rounded-full bg-gradient-to-b from-[#961014] to-[#7a0008] px-5 py-2.5 text-[12.5px] font-semibold text-white shadow-[0_1px_2px_rgba(79,0,5,0.2),0_10px_22px_-10px_rgba(122,0,8,0.55),inset_0_1px_0_rgba(255,255,255,0.15)] transition-all duration-200 hover:-translate-y-0.5 hover:shadow-[0_1px_2px_rgba(79,0,5,0.25),0_14px_30px_-10px_rgba(122,0,8,0.7),inset_0_1px_0_rgba(255,255,255,0.2)] active:scale-[0.985] disabled:cursor-not-allowed disabled:opacity-50 disabled:hover:translate-y-0 disabled:hover:shadow-[0_1px_2px_rgba(79,0,5,0.2),0_10px_22px_-10px_rgba(122,0,8,0.55),inset_0_1px_0_rgba(255,255,255,0.15)] motion-reduce:transition-none motion-reduce:hover:translate-y-0 ${FOCUS_RING}`}
                >
                  <span className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/20 to-transparent transition-transform duration-700 group-hover:translate-x-full" />

                  {loading ? (
                    <>
                      <Loader2 size={14} className="animate-spin" />
                      <span className="relative">Enregistrement…</span>
                    </>
                  ) : (
                    <>
                      <span className="relative">Vérifier l'examen</span>
                      <ArrowRight
                        size={14}
                        strokeWidth={2.4}
                        className="relative transition-transform duration-200 group-hover:translate-x-1 motion-reduce:group-hover:translate-x-0"
                      />
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ===== MODAL RACCOURCIS ===== */}
      {showShortcuts && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-[#0f172a]/40 backdrop-blur-sm" onClick={() => setShowShortcuts(false)} />
          <div
            className="relative w-full max-w-md overflow-hidden rounded-[24px] border border-[#0f172a]/20 bg-white"
            style={{ animation: 'examaiModalSlideUp 240ms cubic-bezier(0.22, 1, 0.36, 1) both' }}
          >
            <div className="flex items-center justify-between border-b border-[#0f172a]/10 p-5">
              <div className="flex items-center gap-2.5">
                <span className="flex h-9 w-9 items-center justify-center rounded-[11px] bg-[#0f172a]/[0.08]">
                  <Sparkles size={15} className="text-[#0f172a]" strokeWidth={2.4} />
                </span>
                <p className="examai-serif text-[15px] font-semibold text-[#0f172a]">Raccourcis clavier</p>
              </div>
              <button onClick={() => setShowShortcuts(false)} aria-label="Fermer" className="flex h-8 w-8 items-center justify-center rounded-full text-[#0f172a]/60 hover:bg-[#0f172a]/[0.05]">
                <X size={14} />
              </button>
            </div>
            <div className="p-5">
              <div className="space-y-2">
                {[
                  { keys: ['Ctrl', 'S'], label: 'Enregistrer le brouillon' },
                  { keys: ['Ctrl', 'D'], label: 'Dupliquer la question sélectionnée' },
                  { keys: ['Ctrl', 'Enter'], label: 'Vérifier l\'examen' },
                  { keys: ['Ctrl', 'K'], label: 'Rechercher une question' },
                  { keys: ['?'], label: 'Afficher/masquer les raccourcis' },
                ].map((s, i) => (
                  <div key={i} className="flex items-center justify-between gap-3 rounded-[10px] bg-[#0f172a]/[0.03] px-3 py-2">
                    <span className="text-[12.5px] font-medium text-[#0f172a]/75">{s.label}</span>
                    <span className="flex shrink-0 items-center gap-1">
                      {s.keys.map((k, j) => (
                        <kbd key={j} className="rounded-md border border-[#0f172a]/20 bg-white px-2 py-0.5 font-mono text-[10.5px] font-bold text-[#0f172a] shadow-[0_1px_2px_rgba(15,23,42,0.08)]">
                          {k}
                        </kbd>
                      ))}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ===== MODAL APERÇU ===== */}
      {showApercu && (
        <ApercuModal questions={questions} totalPoints={totalPoints} onClose={() => setShowApercu(false)} />
      )}

      {/* ===== MODAL SUPPRESSION ===== */}
      {questionASupprimer && (
        <DeleteConfirmModal
          question={questionASupprimer.question}
          index={questionASupprimer.index}
          onCancel={() => setQuestionASupprimer(null)}
          onConfirm={confirmerSuppression}
        />
      )}
    </WizardShell>
  )
}

/* ===== CARTE DE QUESTION ===== */
function QuestionCard({ index, total, question, onChange, onDuplicate, onDelete, onUp, onDown, canUp, canDown }) {
  const complete = questionComplete(question)
  return (
    <div
      id={`question-${question.id}`}
      className={`group rounded-[20px] border-2 bg-white p-5 transition-colors ${
        complete ? 'border-[#0f172a]/20' : 'border-amber-300'
      }`}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2 text-[12px] font-medium text-[#0f172a]/55">
          <span className="flex items-center gap-1.5 rounded-full bg-[#7a0008]/[0.08] px-2.5 py-1 font-semibold text-[#7a0008]">
            <GripVertical size={11} className="opacity-40" />
            Q{index + 1}
          </span>
          <span className="rounded-full border border-[#0f172a]/15 px-2.5 py-1 text-[#0f172a]/70">
            {TYPE_LABEL[question.type]}
          </span>
          <label className={`flex items-center gap-1.5 rounded-full border border-[#0f172a]/15 px-2.5 py-1 ${FOCUS_RING}`}>
            <input
              type="number"
              min={0}
              value={question.points}
              onChange={(e) => onChange({ points: Math.max(0, Number(e.target.value) || 0) })}
              aria-label={`Points pour la question ${index + 1}`}
              className="w-7 border-none bg-transparent text-center text-[12px] font-semibold text-[#0f172a] outline-none"
            />
            <span className="text-[#0f172a]/50">pts</span>
          </label>
          {!complete && (
            <span className="flex items-center gap-1 rounded-full bg-amber-100 px-2 py-1 text-[10px] font-bold text-amber-800">
              <AlertCircle size={10} />
              Incomplète
            </span>
          )}
        </div>

        <div className="flex shrink-0 items-center gap-1 opacity-0 transition-opacity group-hover:opacity-100 focus-within:opacity-100">
          <button
            type="button"
            onClick={(e) => { e.stopPropagation(); if (canUp) onUp() }}
            disabled={!canUp}
            aria-label="Monter la question"
            title="Monter"
            className={`${ACTION_BTN} ${FOCUS_RING}`}
          >
            <ArrowUp size={14} strokeWidth={2.2} />
          </button>
          <button
            type="button"
            onClick={(e) => { e.stopPropagation(); if (canDown) onDown() }}
            disabled={!canDown}
            aria-label="Descendre la question"
            title="Descendre"
            className={`${ACTION_BTN} ${FOCUS_RING}`}
          >
            <ArrowDown size={14} strokeWidth={2.2} />
          </button>
          <button
            type="button"
            onClick={(e) => { e.stopPropagation(); onDuplicate() }}
            aria-label="Dupliquer"
            title="Dupliquer"
            className={`${ACTION_BTN} ${FOCUS_RING}`}
          >
            <Copy size={14} strokeWidth={2.2} />
          </button>
          <button
            type="button"
            onClick={(e) => { e.stopPropagation(); onDelete() }}
            aria-label="Supprimer"
            title="Supprimer"
            className={`${ACTION_BTN_DANGER} ${FOCUS_RING}`}
          >
            <Trash2 size={14} strokeWidth={2.2} />
          </button>
        </div>
      </div>

      <div className="relative mt-3.5">
        <Pencil size={12} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-[#0f172a]/40" aria-hidden="true" />
        <input
          value={question.question}
          onChange={(e) => onChange({ question: e.target.value })}
          placeholder="Énoncé de la question"
          aria-label={`Énoncé de la question ${index + 1}`}
          className={`w-full rounded-[12px] border border-[#0f172a]/20 bg-white py-2.5 pl-9 pr-3.5 text-[14px] font-medium text-[#0f172a] outline-none transition-all placeholder:font-normal placeholder:text-[#0f172a]/35 focus:border-[#0f172a]/50 focus:shadow-[0_0_0_4px_rgba(15,23,42,0.10)] ${FOCUS_RING}`}
        />
      </div>

      {/* ===== NOUVEAU : champs communs (titre_exercice / support / tableau /
          image) — remplis par le backend (voir quiz_engine.py) mais
          jusqu'ici jamais affiches ici. Important surtout pour un exercice
          de "lecture" : cote backend il est aplati en plusieurs questions
          qui partagent le meme `support` (le texte de lecture) — sans ce
          bloc, l'enseignant verrait la question sans jamais voir le texte
          auquel elle se rapporte. ===== */}
      {(question.titre_exercice || question.support || question.tableau || question.image) && (
        <div className="mt-3 space-y-2 rounded-[14px] border border-[#0f172a]/10 bg-[#0f172a]/[0.02] p-3">
          {question.titre_exercice != null && (
            <input
              value={question.titre_exercice || ''}
              onChange={(e) => onChange({ titre_exercice: e.target.value })}
              placeholder="Titre de l'exercice (ex : Lecture)"
              aria-label={`Titre de l'exercice pour la question ${index + 1}`}
              className={`w-full rounded-[10px] border border-dashed border-[#7a0008]/30 bg-white px-3 py-1.5 text-[12.5px] font-bold text-[#7a0008] outline-none ${FOCUS_RING}`}
            />
          )}

          {question.support != null && (
            <div>
              <p className="mb-1 text-[10.5px] font-bold uppercase tracking-wide text-[#0f172a]/40">
                Texte / document de support
              </p>
              <textarea
                rows={3}
                value={question.support || ''}
                onChange={(e) => onChange({ support: e.target.value })}
                placeholder="Texte que l'élève doit lire avant de répondre"
                aria-label={`Support pour la question ${index + 1}`}
                className={`w-full rounded-[10px] border border-[#0f172a]/15 bg-white px-3 py-2 text-[13px] italic text-[#0f172a]/85 outline-none transition-colors focus:border-[#0f172a]/40 ${FOCUS_RING}`}
              />
            </div>
          )}

          {question.tableau && (
            <div className="overflow-x-auto rounded-[10px] border border-[#0f172a]/15 bg-white">
              <table className="w-full text-[12.5px]">
                <thead>
                  <tr className="bg-[#0f172a]/[0.04]">
                    {question.tableau.headers.map((h, i) => (
                      <th key={i} className="p-1.5">
                        <input
                          value={h}
                          onChange={(e) => {
                            const tableau = { ...question.tableau, headers: [...question.tableau.headers] }
                            tableau.headers[i] = e.target.value
                            onChange({ tableau })
                          }}
                          aria-label={`En-tête de colonne ${i + 1}`}
                          className="w-full bg-transparent text-center text-[12.5px] font-bold text-[#0f172a] outline-none"
                        />
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {question.tableau.rows.map((row, r) => (
                    <tr key={r} className="border-t border-[#0f172a]/10">
                      {row.map((cell, c) => (
                        <td key={c} className="p-1.5">
                          <input
                            value={cell}
                            onChange={(e) => {
                              const tableau = { ...question.tableau, rows: question.tableau.rows.map((rr) => [...rr]) }
                              tableau.rows[r][c] = e.target.value
                              onChange({ tableau })
                            }}
                            aria-label={`Ligne ${r + 1}, colonne ${c + 1}`}
                            className="w-full bg-transparent text-center text-[12.5px] text-[#0f172a] outline-none"
                          />
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {question.image && (question.image.url || question.image.description) && (
            <div className="flex items-start gap-3 rounded-[10px] border border-[#0f172a]/15 bg-white p-2.5">
              {question.image.url ? (
                <img
                  src={question.image.url}
                  alt={question.image.alt_text || ''}
                  className="h-20 w-20 shrink-0 rounded-[8px] border border-[#0f172a]/10 object-cover"
                />
              ) : (
                <span className="flex h-20 w-20 shrink-0 items-center justify-center rounded-[8px] border border-dashed border-[#0f172a]/25 text-center text-[10px] leading-tight text-[#0f172a]/40">
                  Pas encore générée
                </span>
              )}
              <input
                value={question.image.description || ''}
                onChange={(e) => onChange({ image: { ...question.image, description: e.target.value } })}
                placeholder="Description de l'image"
                aria-label={`Description de l'image pour la question ${index + 1}`}
                className="min-w-0 flex-1 self-center rounded-[10px] border border-[#0f172a]/15 px-3 py-1.5 text-[13px] text-[#0f172a] outline-none"
              />
            </div>
          )}
        </div>
      )}

      <div className="mt-3.5">
        {question.type === 'qcm' && (
          <div className="grid gap-2 sm:grid-cols-2">
            {question.options.map((opt, i) => {
              const correct = question.reponseCorrecteIndex === i
              return (
                <label
                  key={i}
                  className={`flex items-center gap-2.5 rounded-[12px] border px-3 py-2 text-[13px] transition-colors ${
                    correct
                      ? 'border-[#2f855a]/40 bg-[#2f855a]/[0.05] shadow-[0_2px_6px_-2px_rgba(47,133,90,0.15)]'
                      : 'border-[#0f172a]/15 hover:border-[#0f172a]/30'
                  }`}
                >
                  <input
                    type="radio"
                    name={`${question.id}-correct`}
                    checked={correct}
                    onChange={() => onChange({ reponseCorrecteIndex: i })}
                    className="h-4 w-4 shrink-0 border-[#0f172a]/30 text-[#2f855a] focus:ring-[#2f855a]/30"
                  />
                  <input
                    value={opt}
                    onChange={(e) => {
                      const options = [...question.options]
                      options[i] = e.target.value
                      onChange({ options })
                    }}
                    aria-label={`Option ${i + 1}`}
                    className="min-w-0 flex-1 border-none bg-transparent text-[13px] text-[#0f172a] outline-none"
                  />
                  {correct && <Check size={13} strokeWidth={3} className="shrink-0 text-[#2f855a]" />}
                </label>
              )
            })}
          </div>
        )}

        {question.type === 'vrai_faux' && (
          <div className="flex gap-2">
            {[{ v: true, label: 'Vrai' }, { v: false, label: 'Faux' }].map(({ v, label }) => {
              const active = question.reponseCorrecte === v
              return (
                <button
                  key={label}
                  type="button"
                  onClick={() => onChange({ reponseCorrecte: v })}
                  className={`flex items-center gap-1.5 rounded-full border px-4 py-1.5 text-[13px] font-semibold transition-all ${FOCUS_RING} ${
                    active
                      ? 'border-transparent bg-[#2f855a] text-white shadow-[0_4px_10px_-4px_rgba(47,133,90,0.4)]'
                      : 'border-[#0f172a]/20 text-[#0f172a]/60 hover:border-[#0f172a]/40'
                  }`}
                >
                  {active && <Check size={12} strokeWidth={3} />}
                  {label}
                </button>
              )
            })}
          </div>
        )}

        {question.type === 'ouverte' && (
          <input
            placeholder="Réponse attendue (pour la correction)"
            value={question.reponseAttendue || ''}
            onChange={(e) => onChange({ reponseAttendue: e.target.value })}
            className={`w-full rounded-[12px] border-2 border-dashed border-[#0f172a]/25 px-3.5 py-2.5 text-[13.5px] text-[#0f172a]/70 outline-none transition-colors focus:border-[#7a0008]/50 focus:text-[#0f172a] ${FOCUS_RING}`}
          />
        )}

        {question.type === 'texte_trous' && (
          <input
            placeholder="Réponse(s) attendue(s) — séparez par des virgules si plusieurs blancs"
            value={question.reponseAttendue || ''}
            onChange={(e) => onChange({ reponseAttendue: e.target.value })}
            aria-label={`Réponse attendue pour la question ${index + 1}`}
            className={`w-full rounded-[12px] border-2 border-dashed border-[#0f172a]/25 px-3.5 py-2.5 text-[13.5px] text-[#0f172a]/70 outline-none transition-colors placeholder:text-[#0f172a]/35 focus:border-[#7a0008]/50 focus:text-[#0f172a] focus:shadow-[0_0_0_4px_rgba(122,0,8,0.08)] ${FOCUS_RING}`}
          />
        )}

        {/* ===== NOUVEAU : 8 types ajoutes cote backend (models.py) ===== */}

        {question.type === 'association' && (
          <div className="space-y-2.5">
            {(question.colonne_gauche || []).map((g, i) => (
              <div key={i} className="flex items-center gap-2">
                <input
                  value={g}
                  onChange={(e) => {
                    const colonne_gauche = [...question.colonne_gauche]
                    colonne_gauche[i] = e.target.value
                    onChange({ colonne_gauche })
                  }}
                  placeholder={`Élément ${i + 1}`}
                  aria-label={`Colonne gauche, élément ${i + 1}`}
                  className={`min-w-0 flex-1 rounded-[10px] border border-[#0f172a]/20 px-3 py-1.5 text-[13px] outline-none focus:border-[#0f172a]/50 ${FOCUS_RING}`}
                />
                <span className="shrink-0 text-[#0f172a]/40" aria-hidden="true">↔</span>
                <select
                  value={question.reponseCorrecte?.[i] ?? ''}
                  onChange={(e) => {
                    const reponseCorrecte = [...(question.reponseCorrecte || [])]
                    reponseCorrecte[i] = Number(e.target.value)
                    onChange({ reponseCorrecte })
                  }}
                  aria-label={`Associer l'élément ${i + 1} à…`}
                  className={`rounded-[10px] border border-[#0f172a]/20 px-2 py-1.5 text-[13px] outline-none ${FOCUS_RING}`}
                >
                  <option value="" disabled>Associer à…</option>
                  {(question.colonne_droite || []).map((d, j) => (
                    <option key={j} value={j}>{d || `Option ${j + 1}`}</option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={() => {
                    const colonne_gauche = question.colonne_gauche.filter((_, idx) => idx !== i)
                    const reponseCorrecte = (question.reponseCorrecte || []).filter((_, idx) => idx !== i)
                    onChange({ colonne_gauche, reponseCorrecte })
                  }}
                  aria-label={`Supprimer l'élément ${i + 1}`}
                  className={`${ACTION_BTN_DANGER} ${FOCUS_RING}`}
                >
                  <Trash2 size={13} strokeWidth={2.2} />
                </button>
              </div>
            ))}

            <p className="pt-1 text-[10.5px] font-bold uppercase tracking-wide text-[#0f172a]/40">
              Colonne de droite
            </p>
            <div className="grid gap-2 sm:grid-cols-2">
              {(question.colonne_droite || []).map((d, j) => (
                <input
                  key={j}
                  value={d}
                  onChange={(e) => {
                    const colonne_droite = [...question.colonne_droite]
                    colonne_droite[j] = e.target.value
                    onChange({ colonne_droite })
                  }}
                  placeholder={`Option ${j + 1}`}
                  aria-label={`Colonne droite, option ${j + 1}`}
                  className={`rounded-[10px] border border-[#0f172a]/20 px-3 py-1.5 text-[13px] outline-none focus:border-[#0f172a]/50 ${FOCUS_RING}`}
                />
              ))}
            </div>

            <button
              type="button"
              onClick={() => onChange({
                colonne_gauche: [...(question.colonne_gauche || []), ''],
                colonne_droite: [...(question.colonne_droite || []), ''],
                reponseCorrecte: [...(question.reponseCorrecte || []), (question.colonne_droite || []).length],
              })}
              className={`text-[12px] font-bold text-[#7a0008] ${FOCUS_RING}`}
            >
              + Ajouter une paire
            </button>
          </div>
        )}

        {question.type === 'remise_en_ordre' && (
          <div className="space-y-2">
            {(question.elements || []).map((el, i) => {
              const rc = question.reponseCorrecte && question.reponseCorrecte.length === question.elements.length
                ? question.reponseCorrecte
                : question.elements.map((_, k) => k)
              return (
                <div key={i} className="flex items-center gap-2">
                  <input
                    type="number"
                    min={1}
                    max={question.elements.length}
                    value={rc.indexOf(i) + 1}
                    onChange={(e) => {
                      const pos = Math.max(1, Math.min(question.elements.length, Number(e.target.value) || 1)) - 1
                      const next = [...rc]
                      const old = next.indexOf(i)
                      next.splice(old, 1)
                      next.splice(pos, 0, i)
                      onChange({ reponseCorrecte: next })
                    }}
                    aria-label={`Position correcte de l'élément ${i + 1}`}
                    className={`w-14 shrink-0 rounded-[10px] border border-[#0f172a]/20 py-1.5 text-center text-[13px] outline-none ${FOCUS_RING}`}
                  />
                  <input
                    value={el}
                    onChange={(e) => {
                      const elements = [...question.elements]
                      elements[i] = e.target.value
                      onChange({ elements })
                    }}
                    placeholder={`Élément ${i + 1}`}
                    aria-label={`Texte de l'élément ${i + 1}`}
                    className={`min-w-0 flex-1 rounded-[10px] border border-[#0f172a]/20 px-3 py-1.5 text-[13px] outline-none focus:border-[#0f172a]/50 ${FOCUS_RING}`}
                  />
                </div>
              )
            })}
            <p className="text-[11px] font-bold italic text-[#0f172a]/40">
              Le nombre à gauche est le rang correct (1 = en premier).
            </p>
          </div>
        )}

        {question.type === 'tri' && (
          <div className="space-y-3">
            <div>
              <p className="mb-1.5 text-[10.5px] font-bold uppercase tracking-wide text-[#0f172a]/40">Catégories</p>
              <div className="flex flex-wrap gap-2">
                {(question.categories || []).map((cat, i) => (
                  <input
                    key={i}
                    value={cat}
                    onChange={(e) => {
                      const categories = [...question.categories]
                      categories[i] = e.target.value
                      onChange({ categories })
                    }}
                    placeholder={`Catégorie ${i + 1}`}
                    aria-label={`Catégorie ${i + 1}`}
                    className={`rounded-full border border-[#0f172a]/20 px-3 py-1 text-[12px] font-semibold outline-none focus:border-[#0f172a]/50 ${FOCUS_RING}`}
                  />
                ))}
              </div>
            </div>
            <div className="space-y-2">
              {(question.elements || []).map((el, i) => (
                <div key={i} className="flex items-center gap-2">
                  <input
                    value={el}
                    onChange={(e) => {
                      const elements = [...question.elements]
                      elements[i] = e.target.value
                      onChange({ elements })
                    }}
                    placeholder={`Élément ${i + 1}`}
                    aria-label={`Élément à classer ${i + 1}`}
                    className={`min-w-0 flex-1 rounded-[10px] border border-[#0f172a]/20 px-3 py-1.5 text-[13px] outline-none focus:border-[#0f172a]/50 ${FOCUS_RING}`}
                  />
                  <select
                    value={question.reponseCorrecte?.[i] ?? ''}
                    onChange={(e) => {
                      const reponseCorrecte = [...(question.reponseCorrecte || [])]
                      reponseCorrecte[i] = Number(e.target.value)
                      onChange({ reponseCorrecte })
                    }}
                    aria-label={`Catégorie correcte pour l'élément ${i + 1}`}
                    className={`rounded-[10px] border border-[#0f172a]/20 px-2 py-1.5 text-[13px] outline-none ${FOCUS_RING}`}
                  >
                    <option value="" disabled>Catégorie…</option>
                    {(question.categories || []).map((c, j) => (
                      <option key={j} value={j}>{c || `Catégorie ${j + 1}`}</option>
                    ))}
                  </select>
                </div>
              ))}
            </div>
          </div>
        )}

        {question.type === 'calcul' && (
          <div className="flex flex-wrap items-center gap-2">
            <input
              type="number"
              step="any"
              placeholder="Réponse"
              value={question.reponseAttendue ?? ''}
              onChange={(e) => onChange({ reponseAttendue: e.target.value === '' ? '' : Number(e.target.value) })}
              aria-label={`Réponse numérique pour la question ${index + 1}`}
              className={`w-32 rounded-[12px] border-2 border-dashed border-[#0f172a]/25 px-3.5 py-2.5 text-[13.5px] text-[#0f172a] outline-none focus:border-[#7a0008]/50 ${FOCUS_RING}`}
            />
            <input
              placeholder="Unité (ex : cm, DT)"
              value={question.unite || ''}
              onChange={(e) => onChange({ unite: e.target.value })}
              aria-label="Unité de la réponse"
              className={`w-36 rounded-[12px] border border-[#0f172a]/20 px-3.5 py-2.5 text-[13px] text-[#0f172a] outline-none focus:border-[#0f172a]/50 ${FOCUS_RING}`}
            />
          </div>
        )}

        {question.type === 'legende' && (
          <div className="space-y-2">
            {!(question.image?.url || question.image?.description) && (
              <p className="flex items-center gap-1.5 text-[11.5px] font-bold text-amber-700">
                <AlertCircle size={12} /> Une image est obligatoire pour ce type (voir ci-dessus).
              </p>
            )}
            {(question.reponseCorrecte || []).map((r, i) => (
              <div key={i} className="flex items-center gap-2">
                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[#0f172a]/[0.08] text-[11px] font-bold text-[#0f172a]/70">
                  {i + 1}
                </span>
                <input
                  value={r}
                  onChange={(e) => {
                    const reponseCorrecte = [...question.reponseCorrecte]
                    reponseCorrecte[i] = e.target.value
                    onChange({ reponseCorrecte })
                  }}
                  placeholder={`Nom de l'élément numéro ${i + 1} sur l'image`}
                  aria-label={`Nom de l'élément ${i + 1} à légender`}
                  className={`min-w-0 flex-1 rounded-[10px] border border-[#0f172a]/20 px-3 py-1.5 text-[13px] outline-none focus:border-[#0f172a]/50 ${FOCUS_RING}`}
                />
                <button
                  type="button"
                  onClick={() => onChange({ reponseCorrecte: question.reponseCorrecte.filter((_, idx) => idx !== i) })}
                  aria-label={`Supprimer l'élément ${i + 1}`}
                  className={`${ACTION_BTN_DANGER} ${FOCUS_RING}`}
                >
                  <Trash2 size={13} strokeWidth={2.2} />
                </button>
              </div>
            ))}
            <button
              type="button"
              onClick={() => onChange({ reponseCorrecte: [...(question.reponseCorrecte || []), ''] })}
              className={`text-[12px] font-bold text-[#7a0008] ${FOCUS_RING}`}
            >
              + Ajouter un élément à légender
            </button>
          </div>
        )}

        {question.type === 'dictee' && (
          <textarea
            rows={3}
            placeholder="Texte à dicter, tel que l'élève doit l'écrire"
            value={question.texte_dictee || ''}
            onChange={(e) => onChange({ texte_dictee: e.target.value })}
            aria-label={`Texte de la dictée pour la question ${index + 1}`}
            className={`w-full rounded-[12px] border-2 border-dashed border-[#0f172a]/25 px-3.5 py-2.5 text-[13.5px] text-[#0f172a]/70 outline-none transition-colors focus:border-[#7a0008]/50 focus:text-[#0f172a] ${FOCUS_RING}`}
          />
        )}

        {question.type === 'redaction' && (
          <div className="space-y-2">
            <input
              type="number"
              min={1}
              placeholder="Longueur minimale (mots)"
              value={question.longueur_min_mots || ''}
              onChange={(e) => onChange({ longueur_min_mots: e.target.value === '' ? undefined : Number(e.target.value) })}
              aria-label="Longueur minimale en mots"
              className={`w-52 rounded-[12px] border border-[#0f172a]/20 px-3.5 py-2 text-[13px] text-[#0f172a] outline-none focus:border-[#0f172a]/50 ${FOCUS_RING}`}
            />
            <p className="text-[10.5px] font-bold uppercase tracking-wide text-[#0f172a]/40">
              Critères d'évaluation
            </p>
            {(question.criteres_evaluation || []).map((c, i) => (
              <div key={i} className="flex items-center gap-2">
                <input
                  value={c}
                  onChange={(e) => {
                    const criteres_evaluation = [...question.criteres_evaluation]
                    criteres_evaluation[i] = e.target.value
                    onChange({ criteres_evaluation })
                  }}
                  placeholder={`Critère ${i + 1} (ex : utilise le présent)`}
                  aria-label={`Critère d'évaluation ${i + 1}`}
                  className={`min-w-0 flex-1 rounded-[10px] border border-[#0f172a]/20 px-3 py-1.5 text-[13px] outline-none focus:border-[#0f172a]/50 ${FOCUS_RING}`}
                />
                <button
                  type="button"
                  onClick={() => onChange({ criteres_evaluation: question.criteres_evaluation.filter((_, idx) => idx !== i) })}
                  aria-label={`Supprimer le critère ${i + 1}`}
                  className={`${ACTION_BTN_DANGER} ${FOCUS_RING}`}
                >
                  <Trash2 size={13} strokeWidth={2.2} />
                </button>
              </div>
            ))}
            <button
              type="button"
              onClick={() => onChange({ criteres_evaluation: [...(question.criteres_evaluation || []), ''] })}
              className={`text-[12px] font-bold text-[#7a0008] ${FOCUS_RING}`}
            >
              + Ajouter un critère
            </button>
          </div>
        )}
      </div>
    </div>
  )
}

/* ===== MODAL APERÇU ===== */
function ApercuModal({ questions, totalPoints, onClose }) {
  useEffect(() => {
    function onKey(e) { if (e.key === 'Escape') onClose() }
    document.body.style.overflow = 'hidden'
    window.addEventListener('keydown', onKey)
    return () => {
      document.body.style.overflow = ''
      window.removeEventListener('keydown', onKey)
    }
  }, [onClose])

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center p-3 sm:items-center sm:p-4">
      <div className="absolute inset-0 bg-[#0f172a]/40 backdrop-blur-sm" onClick={onClose} />
      <div
        className="relative max-h-[85vh] w-full max-w-2xl overflow-y-auto rounded-[24px] border border-[#0f172a]/20 bg-white"
        style={{ animation: 'examaiModalSlideUp 240ms cubic-bezier(0.22, 1, 0.36, 1) both' }}
      >
        <div className="sticky top-0 flex items-center justify-between border-b border-[#0f172a]/10 bg-white/95 px-5 py-4 backdrop-blur">
          <div className="flex items-center gap-2.5">
            {/* ✅ Icône Eye — ROUGE */}
            <span className="flex h-9 w-9 items-center justify-center rounded-[11px] bg-[#7a0008]/[0.10]">
              <Eye size={15} className="text-[#7a0008]" />
            </span>
            <div>
              <p className="examai-serif text-[15px] font-semibold text-[#0f172a]">Aperçu de l'examen</p>
              <p className="text-[11px] font-bold italic text-[#0f172a]/50">
                {questions.length} question{questions.length > 1 ? 's' : ''} · {totalPoints} pt{totalPoints > 1 ? 's' : ''}
              </p>
            </div>
          </div>
          <button onClick={onClose} aria-label="Fermer" className="flex h-8 w-8 items-center justify-center rounded-full text-[#0f172a]/60 hover:bg-[#0f172a]/[0.05]">
            <X size={14} />
          </button>
        </div>

        <div className="space-y-4 p-5">
          {questions.map((q, i) => (
            <div key={q.id} className="rounded-[16px] border border-[#0f172a]/15 bg-white p-4">
              <div className="flex items-center justify-between gap-2">
                <span className="flex items-center gap-2 text-[12px] font-bold text-[#0f172a]/70">
                  {/* ✅ Numéro — ROUGE */}
                  <span className="flex h-6 w-6 items-center justify-center rounded-full bg-[#7a0008]/[0.10] text-[11px] font-bold text-[#7a0008]">
                    {i + 1}
                  </span>
                  {TYPE_LABEL[q.type]}
                </span>
                <span className="text-[11px] font-bold text-[#0f172a]/50">{q.points} pt{q.points > 1 ? 's' : ''}</span>
              </div>
              <p className="mt-2.5 examai-serif text-[14.5px] font-semibold text-[#0f172a]">
                {q.question || <span className="italic text-[#0f172a]/40">Énoncé vide</span>}
              </p>

              {q.support && (
                <p className="mt-1.5 rounded-[10px] bg-[#0f172a]/[0.03] px-2.5 py-1.5 text-[12px] italic text-[#0f172a]/65">
                  {q.support}
                </p>
              )}

              {q.type === 'qcm' && (
                <ul className="mt-2.5 space-y-1">
                  {q.options.map((o, j) => (
                    <li key={j} className={`flex items-center gap-2 rounded-[10px] px-2.5 py-1.5 text-[12.5px] ${
                      j === q.reponseCorrecteIndex ? 'bg-[#2f855a]/[0.08] font-semibold text-emerald-800' : 'text-[#0f172a]/70'
                    }`}>
                      <span className="flex h-4 w-4 items-center justify-center rounded-full bg-white text-[9px] font-bold text-[#0f172a]/60">
                        {String.fromCharCode(65 + j)}
                      </span>
                      {o}
                      {j === q.reponseCorrecteIndex && <Check size={12} strokeWidth={3} className="ml-auto text-emerald-600" />}
                    </li>
                  ))}
                </ul>
              )}

              {q.type === 'vrai_faux' && (
                <p className="mt-2 text-[12.5px] text-[#0f172a]/70">
                  Réponse : <span className="font-bold text-emerald-700">{q.reponseCorrecte ? 'Vrai' : 'Faux'}</span>
                </p>
              )}

              {(q.type === 'ouverte' || q.type === 'texte_trous') && (
                <p className="mt-2 rounded-[10px] border border-dashed border-[#0f172a]/20 px-2.5 py-1.5 text-[12px] italic text-[#0f172a]/60">
                  {q.reponseAttendue || 'Aucune réponse attendue spécifiée'}
                </p>
              )}

              {/* ===== NOUVEAU : 8 types ajoutes cote backend ===== */}

              {q.type === 'association' && (
                <ul className="mt-2.5 space-y-1 text-[12.5px] text-[#0f172a]/70">
                  {(q.colonne_gauche || []).map((g, i) => (
                    <li key={i} className="flex items-center gap-1.5">
                      <span className="font-semibold text-[#0f172a]">{g}</span>
                      <span aria-hidden="true">→</span>
                      <span className="font-semibold text-emerald-700">
                        {q.colonne_droite?.[q.reponseCorrecte?.[i]] ?? '?'}
                      </span>
                    </li>
                  ))}
                </ul>
              )}

              {q.type === 'remise_en_ordre' && (
                <p className="mt-2 text-[12.5px] text-[#0f172a]/70">
                  Ordre correct :{' '}
                  <span className="font-semibold text-emerald-700">
                    {(q.reponseCorrecte || []).map((idx) => q.elements?.[idx]).join(' → ')}
                  </span>
                </p>
              )}

              {q.type === 'tri' && (
                <ul className="mt-2.5 space-y-1 text-[12.5px] text-[#0f172a]/70">
                  {(q.elements || []).map((el, i) => (
                    <li key={i}>
                      <span className="font-semibold text-[#0f172a]">{el}</span>
                      {' — '}
                      <span className="font-semibold text-emerald-700">
                        {q.categories?.[q.reponseCorrecte?.[i]] ?? '?'}
                      </span>
                    </li>
                  ))}
                </ul>
              )}

              {q.type === 'calcul' && (
                <p className="mt-2 text-[12.5px] font-bold text-emerald-700">
                  Réponse : {q.reponseAttendue} {q.unite || ''}
                </p>
              )}

              {q.type === 'legende' && (
                <p className="mt-2 text-[12.5px] text-[#0f172a]/70">
                  {(q.reponseCorrecte || []).map((r, i) => `${i + 1}. ${r}`).join('  —  ')}
                </p>
              )}

              {q.type === 'dictee' && (
                <p className="mt-2 rounded-[10px] border border-dashed border-[#0f172a]/20 px-2.5 py-1.5 text-[12px] italic text-[#0f172a]/60">
                  {q.texte_dictee}
                </p>
              )}

              {q.type === 'redaction' && (
                <p className="mt-2 text-[12px] italic text-[#0f172a]/50">
                  {(q.criteres_evaluation || []).join(' · ') || 'Évaluée sur critères (pas de réponse unique)'}
                </p>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

/* ===== MODAL CONFIRMATION SUPPRESSION ===== */
function DeleteConfirmModal({ question, index, onCancel, onConfirm }) {
  const cancelBtnRef = useRef(null)

  useEffect(() => { cancelBtnRef.current?.focus() }, [])

  useEffect(() => {
    function onKey(e) {
      if (e.key === 'Escape') {
        e.preventDefault()
        onCancel()
      }
      if (e.key === 'Enter') {
        e.preventDefault()
        onConfirm()
      }
    }
    document.body.style.overflow = 'hidden'
    window.addEventListener('keydown', onKey)
    return () => {
      document.body.style.overflow = ''
      window.removeEventListener('keydown', onKey)
    }
  }, [onCancel, onConfirm])

  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center p-3 sm:items-center sm:p-4">
      <div
        className="absolute inset-0 bg-[#0f172a]/50 backdrop-blur-sm"
        style={{ animation: 'examaiModalFadeIn 200ms ease-out both' }}
        onClick={onCancel}
      />

      <div
        role="alertdialog"
        aria-modal="true"
        aria-labelledby="delete-modal-title"
        aria-describedby="delete-modal-desc"
        className="relative w-full max-w-md overflow-hidden rounded-[24px] border-2 border-[#7a0008]/30 bg-white"
        style={{ animation: 'examaiModalSlideUp 240ms cubic-bezier(0.22, 1, 0.36, 1) both' }}
      >
        <div className="h-1 w-full bg-[#7a0008]" />

        <div className="flex items-start gap-4 p-6 pb-4">
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-[#7a0008]/[0.10]">
            <Trash2 size={20} className="text-[#7a0008]" strokeWidth={2.2} />
          </div>
          <div className="min-w-0 flex-1">
            <h3
              id="delete-modal-title"
              className="examai-serif text-[18px] font-semibold text-[#0f172a] leading-tight"
            >
              Supprimer cette question ?
            </h3>
            <p
              id="delete-modal-desc"
              className="mt-1.5 text-[12.5px] font-bold italic text-[#0f172a]/60"
            >
              Cette action est irréversible. La question sera définitivement retirée de l'examen.
            </p>
          </div>
          <button
            type="button"
            onClick={onCancel}
            aria-label="Fermer"
            className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-[#0f172a]/50 transition-colors hover:bg-[#0f172a]/[0.06] hover:text-[#0f172a]"
          >
            <X size={14} />
          </button>
        </div>

        <div className="mx-6 mb-5 rounded-[14px] border border-[#0f172a]/15 bg-[#0f172a]/[0.03] p-3.5">
          <div className="mb-2 flex items-center gap-2">
            <span className="flex items-center gap-1.5 rounded-full bg-[#7a0008]/[0.10] px-2 py-0.5 text-[10.5px] font-bold text-[#7a0008]">
              Q{index + 1}
            </span>
            <span className="rounded-full border border-[#0f172a]/15 px-2 py-0.5 text-[10px] font-semibold text-[#0f172a]/60">
              {TYPE_LABEL[question.type]}
            </span>
            <span className="text-[10.5px] font-semibold text-[#0f172a]/50">
              {question.points} pt{question.points > 1 ? 's' : ''}
            </span>
          </div>
          <p className="line-clamp-2 examai-serif text-[13.5px] font-medium text-[#0f172a]">
            {question.question?.trim() || <span className="italic text-[#0f172a]/40">Énoncé vide</span>}
          </p>
        </div>

        <div className="flex flex-col-reverse gap-2 border-t border-[#0f172a]/10 bg-[#0f172a]/[0.02] p-4 sm:flex-row sm:justify-end">
          <button
            ref={cancelBtnRef}
            type="button"
            onClick={onCancel}
            className={`flex items-center justify-center gap-2 rounded-full border border-[#0f172a]/20 bg-white px-5 py-2.5 text-[13px] font-semibold text-[#0f172a] transition-all hover:-translate-y-0.5 hover:border-[#0f172a]/40 hover:shadow-[0_6px_16px_-8px_rgba(15,23,42,0.2)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0f172a]/35 focus-visible:ring-offset-2`}
          >
            Annuler
          </button>
          <button
            type="button"
            onClick={onConfirm}
            className={`group flex items-center justify-center gap-2 rounded-full bg-[#7a0008] px-5 py-2.5 text-[13px] font-semibold text-white shadow-[0_1px_2px_rgba(15,23,42,0.2),0_10px_22px_-8px_rgba(122,0,8,0.5)] transition-all hover:-translate-y-0.5 hover:bg-[#961014] hover:shadow-[0_1px_2px_rgba(15,23,42,0.2),0_14px_28px_-8px_rgba(122,0,8,0.65)] active:scale-[0.985] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#7a0008]/40 focus-visible:ring-offset-2`}
          >
            <Trash2 size={14} strokeWidth={2.4} />
            Supprimer
          </button>
        </div>
      </div>
    </div>
  )
}